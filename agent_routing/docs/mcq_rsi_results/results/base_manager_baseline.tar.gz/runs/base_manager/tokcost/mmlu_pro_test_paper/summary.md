# Token cost per question: mmlu_pro / test_paper

| policy | acc | calls | mgr in | mgr out | adv in | adv out | total | decode | per advisor (tokens/q) |
|---|---|---|---|---|---|---|---|---|---|
| base/manager | 66.2 | 2.53 | 6741 | 310 | 1157 | 1498 | 9706 | 1808 | ext 641, rea 1150, ver 864 |
| draft_only | - | 0.00 | 1120 | 7 | 0 | 0 | 1127 | 7 |  |
