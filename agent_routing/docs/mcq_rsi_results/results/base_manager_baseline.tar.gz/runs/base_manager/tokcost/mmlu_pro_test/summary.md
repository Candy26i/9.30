# Token cost per question: mmlu_pro / test

| policy | acc | calls | mgr in | mgr out | adv in | adv out | total | decode | per advisor (tokens/q) |
|---|---|---|---|---|---|---|---|---|---|
| base/manager | 69.0 | 2.51 | 6620 | 317 | 1145 | 1464 | 9545 | 1780 | ext 634, rea 1160, ver 815 |
| draft_only | - | 0.00 | 1122 | 7 | 0 | 0 | 1129 | 7 |  |
