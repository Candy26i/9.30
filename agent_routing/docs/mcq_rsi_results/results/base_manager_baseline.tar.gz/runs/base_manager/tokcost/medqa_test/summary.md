# Token cost per question: medqa / test

| policy | acc | calls | mgr in | mgr out | adv in | adv out | total | decode | per advisor (tokens/q) |
|---|---|---|---|---|---|---|---|---|---|
| base/manager | 82.8 | 2.98 | 8200 | 179 | 1387 | 2004 | 11770 | 2184 | ext 949, rea 1094, ver 1349 |
| draft_only | - | 0.00 | 1055 | 2 | 0 | 0 | 1058 | 2 |  |
