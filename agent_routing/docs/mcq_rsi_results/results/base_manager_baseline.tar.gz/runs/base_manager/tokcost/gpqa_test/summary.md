# Token cost per question: gpqa / test

| policy | acc | calls | mgr in | mgr out | adv in | adv out | total | decode | per advisor (tokens/q) |
|---|---|---|---|---|---|---|---|---|---|
| base/manager | 39.0 | 2.53 | 6770 | 520 | 1144 | 1664 | 10098 | 2184 | ext 825, rea 1111, ver 872 |
| draft_only | - | 0.00 | 1042 | 10 | 0 | 0 | 1052 | 10 |  |
