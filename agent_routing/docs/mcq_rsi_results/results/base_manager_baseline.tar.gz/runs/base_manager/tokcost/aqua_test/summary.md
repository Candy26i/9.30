# Token cost per question: aqua / test

| policy | acc | calls | mgr in | mgr out | adv in | adv out | total | decode | per advisor (tokens/q) |
|---|---|---|---|---|---|---|---|---|---|
| base/manager | 78.3 | 1.62 | 3698 | 393 | 547 | 671 | 5310 | 1065 | ext 297, rea 520, ver 401 |
| draft_only | - | 0.00 | 946 | 14 | 0 | 0 | 960 | 14 |  |
