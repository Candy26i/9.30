# MCQ RSI report: aqua (main, arms dynamic, static, success, R=3)

Stages 36/36 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r1/S1_dev | all | 0.732 | 0.390 | 34.252 | 0.791 | 0.780 | 0.152 | 0.366 | 0.024 | +0/-0 | +0/-0 | 0 | - | - | pass |
| r1/grpo_dev | all | 0.724 | 0.398 | 32.677 | 0.776 | 0.760 | 0.094 | 0.346 | 0.020 | +9/-7 | +7/-9 | 16 | +7/-9 | 16 | pass |
| r2/dynamic/sft_dev | dynamic | 0.724 | 0.394 | 33.071 | 0.705 | 0.705 | 0.189 | 0.346 | 0.016 | +10/-9 | +16/-18 | 45 | +11/-11 | 44 | pass |
| r2/dynamic/grpo_dev | dynamic | 0.681 | 0.406 | 27.559 | 0.591 | 0.591 | 0.209 | 0.295 | 0.020 | +10/-6 | +8/-21 | 52 | +5/-16 | 29 | pass |
| r2/static/sft_dev | static | 0.744 | 0.394 | 35.039 | 0.752 | 0.752 | 0.152 | 0.366 | 0.016 | +9/-8 | +10/-7 | 17 | +6/-1 | 8 | pass |
| r2/static/grpo_dev | static | 0.752 | 0.406 | 34.646 | 0.744 | 0.744 | 0.190 | 0.366 | 0.020 | +10/-6 | +13/-8 | 25 | +7/-5 | 16 | pass |
| r2/success/sft_dev | success | 0.819 | 0.406 | 41.339 | 0.992 | 0.992 | 0.003 | 0.429 | 0.016 | +13/-9 | +26/-4 | 56 | +26/-2 | 61 | pass |
| r2/success/grpo_dev | success | 0.823 | 0.394 | 42.913 | 0.984 | 0.984 | 0.007 | 0.445 | 0.016 | +11/-10 | +26/-3 | 54 | +3/-2 | 2 | pass |
| r3/dynamic/sft_dev | dynamic | 0.752 | 0.382 | 37.008 | 0.780 | 0.780 | 0.094 | 0.378 | 0.008 | +11/-13 | +18/-13 | 40 | +14/-7 | 43 | pass |
| r3/dynamic/grpo_dev | dynamic | 0.752 | 0.425 | 32.677 | 0.783 | 0.783 | 0.074 | 0.350 | 0.024 | +21/-12 | +18/-13 | 43 | +7/-7 | 19 | pass |
| r3/static/sft_dev | static | 0.732 | 0.378 | 35.433 | 0.720 | 0.701 | 0.256 | 0.370 | 0.016 | +7/-10 | +12/-12 | 37 | +5/-10 | 22 | pass |
| r3/static/grpo_dev | static | 0.740 | 0.402 | 33.858 | 0.724 | 0.689 | 0.283 | 0.354 | 0.016 | +11/-8 | +13/-11 | 40 | +5/-3 | 15 | pass |
| r3/success/sft_dev | success | 0.815 | 0.394 | 42.126 | 1.000 | 1.000 | 0.000 | 0.445 | 0.024 | +14/-13 | +27/-6 | 58 | +3/-5 | 4 | pass |
| r3/success/grpo_dev | success | 0.827 | 0.417 | 40.945 | 1.000 | 1.000 | 0.000 | 0.437 | 0.028 | +18/-11 | +29/-5 | 58 | +4/-1 | 0 | pass |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| dynamic: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | False | 0.724 | 0.776 | 0.094 |
| 2 | r2/dynamic/grpo_dev | True | 0.724 | 0.705 | 0.189 |
| 3 | r3/dynamic/grpo_dev | False | 0.752 | 0.783 | 0.074 |

| static: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | False | 0.724 | 0.776 | 0.094 |
| 2 | r2/static/grpo_dev | False | 0.752 | 0.744 | 0.190 |
| 3 | r3/static/grpo_dev | False | 0.740 | 0.724 | 0.283 |

| success: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | False | 0.724 | 0.776 | 0.094 |
| 2 | r2/success/grpo_dev | False | 0.823 | 0.984 | 0.007 |
| 3 | r3/success/grpo_dev | False | 0.827 | 1.000 | 0.000 |

## Recollections (Tables 1-2 analogues)

| stage | n | A0 commit | A1 best 1 call | AD best | Gain@1 | unsolved | E 100Δ | R 100Δ | V 100Δ | policy call rate |
|---|---|---|---|---|---|---|---|---|---|---|
| r2/collect | 400 | 0.430 | 0.887 | 0.895 | 0.984 | 42 | -3.000 | 2.000 | 42.250 | 0.733 |
| r3/dynamic/collect | 400 | 0.372 | 0.880 | 0.887 | 0.985 | 45 | 0.750 | 2.000 | 48.250 | 0.640 |
| r3/success/collect | 400 | 0.393 | 0.892 | 0.900 | 0.985 | 40 | -1.250 | 2.500 | 46.500 | 0.985 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| r2/dynamic/select | dynamic | 547 | 172 | 189 | 186 | 186 | 172 |
| static/select | static | 402 | - | - | - | - | - |
| r2/success/select | success | 660 | 59 | 302 | 299 | 299 | 59 |
| r3/dynamic/select | dynamic | 564 | 149 | 209 | 206 | 206 | 149 |
| r3/success/select | success | 670 | 53 | 310 | 307 | 307 | 53 |

## FA-GRPO

| stage | lr | steps | selected step | guard ok | informative frac |
|---|---|---|---|---|---|
| r1/grpo | 0.000 | 40 | 32 | False | 0.431 |
| r2/dynamic/grpo | 0.000 | 32 | 24 | False | 0.521 |
| r2/static/grpo | 0.000 | 64 | 64 | True | 0.375 |
| r2/success/grpo | 0.000 | 64 | 64 | True | 0.349 |
| r3/dynamic/grpo | 0.000 | 64 | 64 | True | 0.348 |
| r3/static/grpo | 0.000 | 24 | 16 | False | 0.295 |
| r3/success/grpo | 0.000 | 64 | 64 | True | 0.409 |

## Gates

- r1/S1_dev: parity fail
- r1/grpo_dev: grpo_accepted 
- r2/dynamic/grpo_dev: grpo_rejected ['accuracy 0.6811 < S_k 0.7244 - 0.01']
- r2/static/grpo_dev: grpo_accepted 
- r2/success/grpo_dev: grpo_accepted 
- r3/dynamic/grpo_dev: grpo_accepted 
- r3/static/grpo_dev: grpo_accepted 
- r3/success/grpo_dev: grpo_accepted 

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/S_1/dev_forced_extractor | S_1 | dev | extractor | 254 | - | 0.228 | - | 1.000 | - | BROKEN: valid_answer_rate=0.6259842519685039 |
| final/S_1/dev_forced_extractor+reasoner+verifier | S_1 | dev | extractor,reasoner,verifier | 254 | - | 0.768 | - | 3.000 | - | pass |
| final/S_1/dev_forced_reasoner | S_1 | dev | reasoner | 254 | - | 0.382 | - | 1.000 | - | valid_answer_rate=0.9488188976377953 |
| final/S_1/dev_forced_verifier | S_1 | dev | verifier | 254 | - | 0.772 | - | 1.000 | - | valid_answer_rate=0.9960629921259843 |
| final/S_1/test | S_1 | test | - | 254 | 0.362 | 0.772 | 40.945 | 0.776 | 0.204 | pass |
| final/dynamic/dev_forced_extractor | dynamic | dev | extractor | 254 | - | 0.350 | - | 1.000 | - | BROKEN: valid_answer_rate=0.8188976377952756 |
| final/dynamic/dev_forced_extractor+reasoner+verifier | dynamic | dev | extractor,reasoner,verifier | 254 | - | 0.772 | - | 3.000 | - | pass |
| final/dynamic/dev_forced_reasoner | dynamic | dev | reasoner | 254 | - | 0.398 | - | 1.000 | - | valid_answer_rate=0.9645669291338582 |
| final/dynamic/dev_forced_verifier | dynamic | dev | verifier | 254 | - | 0.760 | - | 1.000 | - | pass |
| final/dynamic/test | dynamic | test | - | 254 | 0.409 | 0.776 | 36.614 | 0.768 | 0.258 | pass |
| final/static/dev_forced_extractor | static | dev | extractor | 254 | - | 0.366 | - | 1.000 | - | BROKEN: valid_answer_rate=0.8385826771653543 |
| final/static/dev_forced_extractor+reasoner+verifier | static | dev | extractor,reasoner,verifier | 254 | - | 0.776 | - | 3.000 | - | pass |
| final/static/dev_forced_reasoner | static | dev | reasoner | 254 | - | 0.413 | - | 1.000 | - | valid_answer_rate=0.9448818897637795 |
| final/static/dev_forced_verifier | static | dev | verifier | 254 | - | 0.776 | - | 1.000 | - | valid_answer_rate=0.9921259842519685 |
| final/static/test | static | test | - | 254 | 0.382 | 0.736 | 35.433 | 0.724 | 0.273 | pass |
| final/success/dev_forced_extractor | success | dev | extractor | 254 | - | 0.390 | - | 1.000 | - | valid_answer_rate=0.9566929133858267 |
| final/success/dev_forced_extractor+reasoner+verifier | success | dev | extractor,reasoner,verifier | 254 | - | 0.768 | - | 3.000 | - | pass |
| final/success/dev_forced_reasoner | success | dev | reasoner | 254 | - | 0.409 | - | 1.000 | - | pass |
| final/success/dev_forced_verifier | success | dev | verifier | 254 | - | 0.764 | - | 1.000 | - | pass |
| final/success/test | success | test | - | 254 | 0.406 | 0.827 | 42.126 | 1.000 | 0.000 | pass |
