# MCQ RSI report: gpqa (main, arms dynamic, static, success, R=3)

Stages 36/36 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r1/S1_dev | all | 0.530 | 0.410 | 12.000 | 0.620 | 0.620 | -0.024 | 0.150 | 0.030 | +0/-0 | +0/-0 | 0 | - | - | pass |
| r1/grpo_dev | all | 0.530 | 0.410 | 12.000 | 0.620 | 0.620 | -0.024 | 0.150 | 0.030 | +0/-0 | +0/-0 | 0 | +0/-0 | 0 | pass |
| r2/dynamic/sft_dev | dynamic | 0.530 | 0.430 | 10.000 | 0.620 | 0.620 | 0.068 | 0.130 | 0.030 | +2/-0 | +4/-4 | 10 | +4/-4 | 10 | pass |
| r2/dynamic/grpo_dev | dynamic | 0.540 | 0.430 | 11.000 | 0.580 | 0.580 | 0.038 | 0.120 | 0.010 | +3/-1 | +4/-3 | 16 | +4/-3 | 10 | pass |
| r2/static/sft_dev | static | 0.520 | 0.420 | 10.000 | 0.670 | 0.670 | 0.170 | 0.140 | 0.040 | +2/-1 | +3/-4 | 11 | +3/-4 | 11 | pass |
| r2/static/grpo_dev | static | 0.520 | 0.440 | 8.000 | 0.700 | 0.700 | 0.114 | 0.120 | 0.040 | +3/-0 | +1/-2 | 14 | +2/-2 | 5 | pass |
| r2/success/sft_dev | success | 0.530 | 0.420 | 11.000 | 1.000 | 1.000 | 0.000 | 0.160 | 0.050 | +3/-2 | +8/-8 | 38 | +8/-8 | 38 | pass |
| r2/success/grpo_dev | success | 0.510 | 0.390 | 12.000 | 1.000 | 1.000 | 0.000 | 0.160 | 0.040 | +2/-4 | +9/-11 | 38 | +1/-3 | 0 | pass |
| r3/dynamic/sft_dev | dynamic | 0.520 | 0.440 | 8.000 | 0.660 | 0.660 | 0.083 | 0.120 | 0.040 | +5/-2 | +4/-5 | 18 | +0/-2 | 10 | pass |
| r3/dynamic/grpo_dev | dynamic | 0.530 | 0.420 | 11.000 | 0.670 | 0.670 | 0.170 | 0.150 | 0.040 | +4/-3 | +4/-4 | 23 | +3/-2 | 5 | pass |
| r3/static/sft_dev | static | 0.500 | 0.410 | 9.000 | 0.590 | 0.590 | 0.132 | 0.140 | 0.050 | +3/-3 | +3/-6 | 17 | +2/-4 | 15 | pass |
| r3/static/grpo_dev | static | 0.550 | 0.460 | 9.000 | 0.530 | 0.530 | 0.136 | 0.130 | 0.040 | +7/-2 | +8/-6 | 17 | +8/-3 | 10 | pass |
| r3/success/sft_dev | success | 0.550 | 0.410 | 14.000 | 1.000 | 1.000 | 0.000 | 0.170 | 0.030 | +2/-2 | +8/-6 | 38 | +3/-1 | 0 | pass |
| r3/success/grpo_dev | success | 0.580 | 0.420 | 16.000 | 1.000 | 1.000 | 0.000 | 0.200 | 0.040 | +2/-1 | +10/-5 | 38 | +3/-0 | 0 | pass |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| dynamic: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | False | 0.530 | 0.620 | -0.024 |
| 2 | r2/dynamic/grpo_dev | False | 0.540 | 0.580 | 0.038 |
| 3 | r3/dynamic/grpo_dev | False | 0.530 | 0.670 | 0.170 |

| static: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | False | 0.530 | 0.620 | -0.024 |
| 2 | r2/static/grpo_dev | False | 0.520 | 0.700 | 0.114 |
| 3 | r3/static/grpo_dev | False | 0.550 | 0.530 | 0.136 |

| success: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | False | 0.530 | 0.620 | -0.024 |
| 2 | r2/success/grpo_dev | True | 0.530 | 1.000 | 0.000 |
| 3 | r3/success/grpo_dev | False | 0.580 | 1.000 | 0.000 |

## Recollections (Tables 1-2 analogues)

| stage | n | A0 commit | A1 best 1 call | AD best | Gain@1 | unsolved | E 100Δ | R 100Δ | V 100Δ | policy call rate |
|---|---|---|---|---|---|---|---|---|---|---|
| r2/collect | 200 | 0.390 | 0.705 | 0.715 | 0.969 | 57 | 3.500 | 9.000 | 22.000 | 0.555 |
| r3/dynamic/collect | 200 | 0.395 | 0.700 | 0.720 | 0.938 | 56 | 2.500 | 9.500 | 21.000 | 0.525 |
| r3/success/collect | 200 | 0.390 | 0.695 | 0.720 | 0.924 | 56 | 2.500 | 10.000 | 21.000 | 1.000 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| r2/dynamic/select | dynamic | 210 | 78 | 67 | 65 | 65 | 78 |
| static/select | static | 148 | - | - | - | - | - |
| r2/success/select | success | 267 | 21 | 124 | 122 | 122 | 21 |
| r3/dynamic/select | dynamic | 213 | 79 | 69 | 65 | 65 | 79 |
| r3/success/select | success | 268 | 25 | 124 | 119 | 119 | 25 |

## FA-GRPO

| stage | lr | steps | selected step | guard ok | informative frac |
|---|---|---|---|---|---|
| r1/grpo | 0.000 | 8 | 0 | False | 0.323 |
| r2/dynamic/grpo | 0.000 | 64 | 64 | True | 0.285 |
| r2/static/grpo | 0.000 | 64 | 64 | True | 0.315 |
| r2/success/grpo | 0.000 | 64 | 64 | True | 0.301 |
| r3/dynamic/grpo | 0.000 | 64 | 64 | True | 0.344 |
| r3/static/grpo | 0.000 | 64 | 64 | True | 0.395 |
| r3/success/grpo | 0.000 | 64 | 64 | True | 0.488 |

## Gates

- r1/S1_dev: parity not_applicable
- r1/grpo_dev: grpo_accepted 
- r2/dynamic/grpo_dev: grpo_accepted 
- r2/static/grpo_dev: grpo_accepted 
- r2/success/grpo_dev: grpo_rejected ['accuracy 0.5100 < S_k 0.5300 - 0.01']
- r3/dynamic/grpo_dev: grpo_accepted 
- r3/static/grpo_dev: grpo_accepted 
- r3/success/grpo_dev: grpo_accepted 

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/S_1/dev_forced_extractor | S_1 | dev | extractor | 100 | - | 0.420 | - | 1.000 | - | pass |
| final/S_1/dev_forced_extractor+reasoner+verifier | S_1 | dev | extractor,reasoner,verifier | 100 | - | 0.510 | - | 3.000 | - | pass |
| final/S_1/dev_forced_reasoner | S_1 | dev | reasoner | 100 | - | 0.440 | - | 1.000 | - | pass |
| final/S_1/dev_forced_verifier | S_1 | dev | verifier | 100 | - | 0.520 | - | 1.000 | - | pass |
| final/S_1/test | S_1 | test | - | 100 | 0.410 | 0.540 | 13.000 | 0.520 | -0.028 | pass |
| final/dynamic/dev_forced_extractor | dynamic | dev | extractor | 100 | - | 0.480 | - | 1.000 | - | valid_answer_rate=0.99 |
| final/dynamic/dev_forced_extractor+reasoner+verifier | dynamic | dev | extractor,reasoner,verifier | 100 | - | 0.520 | - | 3.000 | - | pass |
| final/dynamic/dev_forced_reasoner | dynamic | dev | reasoner | 100 | - | 0.440 | - | 1.000 | - | pass |
| final/dynamic/dev_forced_verifier | dynamic | dev | verifier | 100 | - | 0.530 | - | 1.000 | - | pass |
| final/dynamic/test | dynamic | test | - | 100 | 0.420 | 0.550 | 13.000 | 0.600 | 0.090 | pass |
| final/static/dev_forced_extractor | static | dev | extractor | 100 | - | 0.460 | - | 1.000 | - | pass |
| final/static/dev_forced_extractor+reasoner+verifier | static | dev | extractor,reasoner,verifier | 100 | - | 0.510 | - | 3.000 | - | pass |
| final/static/dev_forced_reasoner | static | dev | reasoner | 100 | - | 0.420 | - | 1.000 | - | pass |
| final/static/dev_forced_verifier | static | dev | verifier | 100 | - | 0.520 | - | 1.000 | - | pass |
| final/static/test | static | test | - | 100 | 0.420 | 0.500 | 8.000 | 0.470 | -0.134 | pass |
| final/success/dev_forced_extractor | success | dev | extractor | 100 | - | 0.420 | - | 1.000 | - | BROKEN: valid_answer_rate=0.89 |
| final/success/dev_forced_extractor+reasoner+verifier | success | dev | extractor,reasoner,verifier | 100 | - | 0.520 | - | 3.000 | - | pass |
| final/success/dev_forced_reasoner | success | dev | reasoner | 100 | - | 0.460 | - | 1.000 | - | valid_answer_rate=0.98 |
| final/success/dev_forced_verifier | success | dev | verifier | 100 | - | 0.530 | - | 1.000 | - | pass |
| final/success/test | success | test | - | 100 | 0.450 | 0.580 | 13.000 | 1.000 | 0.000 | pass |
