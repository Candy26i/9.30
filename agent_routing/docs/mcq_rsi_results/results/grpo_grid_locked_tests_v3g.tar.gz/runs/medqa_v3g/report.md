# MCQ RSI report: medqa (main, arms dynamic, static, success, R=3)

Stages 36/36 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r1/S1_dev | all | 0.790 | 0.705 | 8.500 | 0.370 | 0.370 | 0.413 | 0.110 | 0.025 | +0/-0 | +0/-0 | 0 | - | - | pass |
| r1/grpo_dev | all | 0.775 | 0.710 | 6.500 | 0.355 | 0.355 | 0.447 | 0.095 | 0.030 | +3/-2 | +1/-4 | 19 | +1/-4 | 19 | pass |
| r2/dynamic/sft_dev | dynamic | 0.805 | 0.715 | 9.000 | 0.300 | 0.300 | 0.390 | 0.115 | 0.025 | +6/-4 | +6/-3 | 38 | +6/-3 | 38 | pass |
| r2/dynamic/grpo_dev | dynamic | 0.780 | 0.730 | 5.000 | 0.230 | 0.230 | 0.218 | 0.070 | 0.025 | +7/-2 | +5/-7 | 48 | +1/-6 | 18 | pass |
| r2/static/sft_dev | static | 0.785 | 0.720 | 6.500 | 0.265 | 0.260 | 0.333 | 0.085 | 0.020 | +6/-3 | +5/-6 | 31 | +5/-6 | 31 | pass |
| r2/static/grpo_dev | static | 0.780 | 0.725 | 5.500 | 0.230 | 0.220 | 0.298 | 0.070 | 0.015 | +6/-2 | +5/-7 | 38 | +3/-4 | 17 | pass |
| r2/success/sft_dev | success | 0.830 | 0.720 | 11.000 | 1.000 | 1.000 | 0.000 | 0.140 | 0.030 | +7/-4 | +14/-6 | 126 | +14/-6 | 126 | pass |
| r2/success/grpo_dev | success | 0.850 | 0.715 | 13.500 | 0.965 | 0.965 | 0.049 | 0.165 | 0.030 | +5/-3 | +17/-5 | 119 | +7/-3 | 7 | pass |
| r3/dynamic/sft_dev | dynamic | 0.780 | 0.740 | 4.000 | 0.175 | 0.175 | 0.205 | 0.050 | 0.010 | +9/-2 | +7/-9 | 51 | +3/-8 | 25 | pass |
| r3/dynamic/grpo_dev | dynamic | 0.775 | 0.740 | 3.500 | 0.145 | 0.145 | 0.194 | 0.040 | 0.005 | +10/-3 | +8/-11 | 57 | +1/-2 | 6 | pass |
| r3/static/sft_dev | static | 0.805 | 0.720 | 8.500 | 0.325 | 0.300 | 0.427 | 0.100 | 0.020 | +5/-2 | +7/-4 | 30 | +5/-1 | 18 | ACKNOWLEDGED: valid_answer_rate=0.995 |
| r3/static/grpo_dev | static | 0.800 | 0.720 | 8.000 | 0.325 | 0.295 | 0.384 | 0.100 | 0.025 | +5/-2 | +7/-5 | 34 | +0/-1 | 10 | valid_answer_rate=0.995 |
| r3/success/sft_dev | success | 0.850 | 0.700 | 15.000 | 0.995 | 0.995 | 0.007 | 0.170 | 0.020 | +5/-6 | +16/-4 | 125 | +5/-1 | 1 | pass |
| r3/success/grpo_dev | success | 0.835 | 0.700 | 13.500 | 0.990 | 0.990 | 0.014 | 0.160 | 0.025 | +10/-11 | +14/-5 | 124 | +3/-6 | 1 | pass |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| dynamic: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | True | 0.790 | 0.370 | 0.413 |
| 2 | r2/dynamic/grpo_dev | True | 0.805 | 0.300 | 0.390 |
| 3 | r3/dynamic/grpo_dev | True | 0.780 | 0.175 | 0.205 |

| static: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | True | 0.790 | 0.370 | 0.413 |
| 2 | r2/static/grpo_dev | True | 0.785 | 0.265 | 0.333 |
| 3 | r3/static/grpo_dev | True | 0.805 | 0.325 | 0.427 |

| success: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | True | 0.790 | 0.370 | 0.413 |
| 2 | r2/success/grpo_dev | True | 0.830 | 1.000 | 0.000 |
| 3 | r3/success/grpo_dev | True | 0.850 | 0.995 | 0.007 |

## Recollections (Tables 1-2 analogues)

| stage | n | A0 commit | A1 best 1 call | AD best | Gain@1 | unsolved | E 100Δ | R 100Δ | V 100Δ | policy call rate |
|---|---|---|---|---|---|---|---|---|---|---|
| r2/collect | 400 | 0.705 | 0.920 | 0.927 | 0.966 | 29 | 7.750 | 15.000 | 12.250 | 0.367 |
| r3/dynamic/collect | 400 | 0.757 | 0.927 | 0.935 | 0.958 | 26 | 5.250 | 11.250 | 7.250 | 0.250 |
| r3/success/collect | 400 | 0.760 | 0.930 | 0.943 | 0.932 | 23 | 5.250 | 11.000 | 7.750 | 1.000 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| r2/dynamic/select | dynamic | 448 | 267 | 92 | 89 | 89 | 267 |
| static/select | static | 315 | - | - | - | - | - |
| r2/success/select | success | 634 | 81 | 278 | 275 | 275 | 81 |
| r3/dynamic/select | dynamic | 358 | 213 | 74 | 71 | 71 | 213 |
| r3/success/select | success | 525 | 64 | 233 | 228 | 228 | 64 |

## FA-GRPO

| stage | lr | steps | selected step | guard ok | informative frac |
|---|---|---|---|---|---|
| r1/grpo | 0.000 | 32 | 24 | False | 0.036 |
| r2/dynamic/grpo | 0.000 | 64 | 64 | True | 0.141 |
| r2/static/grpo | 0.000 | 56 | 48 | False | 0.122 |
| r2/success/grpo | 0.000 | 64 | 64 | True | 0.139 |
| r3/dynamic/grpo | 0.000 | 64 | 64 | True | 0.091 |
| r3/static/grpo | 0.000 | 24 | 16 | False | 0.080 |
| r3/success/grpo | 0.000 | 64 | 64 | True | 0.098 |

## Gates

- r1/S1_dev: parity fail
- r1/grpo_dev: grpo_rejected ['accuracy 0.7750 < S_k 0.7900 - 0.01', 'FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r2/dynamic/grpo_dev: grpo_rejected ['accuracy 0.7800 < S_k 0.8050 - 0.01', 'FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r2/static/grpo_dev: grpo_rejected ['FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r2/success/grpo_dev: grpo_rejected ['FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r3/dynamic/grpo_dev: grpo_rejected ['FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r3/static/sft_dev: eval gate ['valid_answer_rate=0.995'] passed on an acknowledgement (Pre-acknowledged per the user delegation of 2026-10-07: only a validity-rate gate failure (unparsed answers, valid >= ACK_MIN_VALID 0.99) may pass; any other failure still stops the run.)
- r3/static/grpo_dev: grpo_rejected ["G_k dev eval failed its gate: ['valid_answer_rate=0.995']", 'FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r3/success/grpo_dev: grpo_rejected ['accuracy 0.8350 < S_k 0.8500 - 0.01', 'FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/S_1/dev_forced_extractor | S_1 | dev | extractor | 200 | - | 0.770 | - | 1.000 | - | valid_answer_rate=0.99 |
| final/S_1/dev_forced_extractor+reasoner+verifier | S_1 | dev | extractor,reasoner,verifier | 200 | - | 0.850 | - | 3.000 | - | pass |
| final/S_1/dev_forced_reasoner | S_1 | dev | reasoner | 200 | - | 0.835 | - | 1.000 | - | pass |
| final/S_1/dev_forced_verifier | S_1 | dev | verifier | 200 | - | 0.865 | - | 1.000 | - | pass |
| final/S_1/test | S_1 | test | - | 500 | 0.734 | 0.788 | 5.400 | 0.366 | 0.362 | pass |
| final/dynamic/dev_forced_extractor | dynamic | dev | extractor | 200 | - | 0.780 | - | 1.000 | - | valid_answer_rate=0.985 |
| final/dynamic/dev_forced_extractor+reasoner+verifier | dynamic | dev | extractor,reasoner,verifier | 200 | - | 0.850 | - | 3.000 | - | pass |
| final/dynamic/dev_forced_reasoner | dynamic | dev | reasoner | 200 | - | 0.830 | - | 1.000 | - | pass |
| final/dynamic/dev_forced_verifier | dynamic | dev | verifier | 200 | - | 0.855 | - | 1.000 | - | pass |
| final/dynamic/test | dynamic | test | - | 500 | 0.756 | 0.786 | 3.000 | 0.170 | 0.209 | pass |
| final/static/dev_forced_extractor | static | dev | extractor | 200 | - | 0.775 | - | 1.000 | - | valid_answer_rate=0.945 |
| final/static/dev_forced_extractor+reasoner+verifier | static | dev | extractor,reasoner,verifier | 200 | - | 0.850 | - | 3.000 | - | pass |
| final/static/dev_forced_reasoner | static | dev | reasoner | 200 | - | 0.830 | - | 1.000 | - | valid_answer_rate=0.99 |
| final/static/dev_forced_verifier | static | dev | verifier | 200 | - | 0.845 | - | 1.000 | - | valid_answer_rate=0.985 |
| final/static/test | static | test | - | 500 | 0.756 | 0.798 | 4.200 | 0.282 | 0.320 | pass |
| final/success/dev_forced_extractor | success | dev | extractor | 200 | - | 0.755 | - | 1.000 | - | valid_answer_rate=0.975 |
| final/success/dev_forced_extractor+reasoner+verifier | success | dev | extractor,reasoner,verifier | 200 | - | 0.850 | - | 3.000 | - | pass |
| final/success/dev_forced_reasoner | success | dev | reasoner | 200 | - | 0.840 | - | 1.000 | - | pass |
| final/success/dev_forced_verifier | success | dev | verifier | 200 | - | 0.855 | - | 1.000 | - | valid_answer_rate=0.995 |
| final/success/test | success | test | - | 500 | 0.740 | 0.802 | 6.200 | 0.994 | 0.008 | pass |
