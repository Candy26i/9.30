# MCQ RSI report: mmlu_pro (main, arms dynamic, R=3)

Stages 16/16 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r1/S1_dev | all | 0.625 | 0.555 | 7.000 | 0.320 | 0.305 | 0.200 | 0.085 | 0.025 | +0/-0 | +0/-0 | 0 | - | - | pass |
| r1/grpo_dev | all | 0.650 | 0.560 | 9.000 | 0.390 | 0.385 | 0.205 | 0.100 | 0.020 | +4/-3 | +7/-2 | 18 | +7/-2 | 18 | pass |
| r2/dynamic/sft_dev | dynamic | 0.570 | 0.520 | 5.000 | 0.115 | 0.115 | 0.079 | 0.055 | 0.010 | +2/-9 | +5/-16 | 49 | +5/-16 | 49 | pass |
| r2/dynamic/grpo_dev | dynamic | 0.575 | 0.530 | 4.500 | 0.120 | 0.120 | 0.075 | 0.055 | 0.010 | +4/-9 | +5/-15 | 52 | +3/-2 | 9 | pass |
| r3/dynamic/sft_dev | dynamic | 0.650 | 0.520 | 13.000 | 0.345 | 0.335 | 0.357 | 0.155 | 0.025 | +4/-11 | +13/-8 | 51 | +19/-4 | 43 | pass |
| r3/dynamic/grpo_dev | dynamic | 0.685 | 0.525 | 16.000 | 0.390 | 0.380 | 0.399 | 0.175 | 0.015 | +4/-10 | +19/-7 | 54 | +7/-0 | 9 | pass |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| dynamic: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | True | 0.625 | 0.320 | 0.200 |
| 2 | r2/dynamic/grpo_dev | False | 0.575 | 0.120 | 0.075 |
| 3 | r3/dynamic/grpo_dev | False | 0.685 | 0.390 | 0.399 |

## Recollections (Tables 1-2 analogues)

| stage | n | A0 commit | A1 best 1 call | AD best | Gain@1 | unsolved | E 100Δ | R 100Δ | V 100Δ | policy call rate |
|---|---|---|---|---|---|---|---|---|---|---|
| r2/collect | 400 | 0.525 | 0.772 | 0.792 | 0.925 | 83 | 0.750 | 2.750 | 18.500 | 0.345 |
| r3/dynamic/collect | 400 | 0.458 | 0.780 | 0.800 | 0.942 | 80 | 2.750 | 6.000 | 26.250 | 0.128 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| r2/dynamic/select | dynamic | 432 | 210 | 115 | 107 | 107 | 210 |
| r3/dynamic/select | dynamic | 465 | 183 | 145 | 137 | 137 | 183 |

## FA-GRPO

| stage | lr | steps | selected step | guard ok | informative frac |
|---|---|---|---|---|---|
| r1/grpo | 0.000 | 24 | 16 | False | 0.104 |
| r2/dynamic/grpo | 0.000 | 64 | 64 | True | 0.258 |
| r3/dynamic/grpo | 0.000 | 48 | 40 | False | 0.215 |

## Gates

- r1/S1_dev: parity pass
- r1/grpo_dev: grpo_rejected ['FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r2/dynamic/sft_dev: SFT flags ['accuracy 0.5700 dropped > 0.03 from 0.6250']
- r2/dynamic/grpo_dev: grpo_accepted 
- r3/dynamic/grpo_dev: grpo_accepted 

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/S_1/dev_forced_extractor | S_1 | dev | extractor | 200 | - | 0.525 | - | 1.000 | - | valid_answer_rate=0.995 |
| final/S_1/dev_forced_extractor+reasoner+verifier | S_1 | dev | extractor,reasoner,verifier | 200 | - | 0.675 | - | 3.000 | - | pass |
| final/S_1/dev_forced_reasoner | S_1 | dev | reasoner | 200 | - | 0.575 | - | 1.000 | - | pass |
| final/S_1/dev_forced_verifier | S_1 | dev | verifier | 200 | - | 0.670 | - | 1.000 | - | pass |
| final/S_1/test | S_1 | test | - | 500 | 0.510 | 0.636 | 12.600 | 0.352 | 0.309 | pass |
| final/S_1/test_paper | S_1 | test_paper | - | 500 | 0.492 | 0.596 | 10.400 | 0.348 | 0.265 | pass |
| final/dynamic/dev_forced_extractor | dynamic | dev | extractor | 200 | - | 0.535 | - | 1.000 | - | valid_answer_rate=0.97 |
| final/dynamic/dev_forced_extractor+reasoner+verifier | dynamic | dev | extractor,reasoner,verifier | 200 | - | 0.685 | - | 3.000 | - | pass |
| final/dynamic/dev_forced_reasoner | dynamic | dev | reasoner | 200 | - | 0.580 | - | 1.000 | - | valid_answer_rate=0.98 |
| final/dynamic/dev_forced_verifier | dynamic | dev | verifier | 200 | - | 0.685 | - | 1.000 | - | pass |
| final/dynamic/test | dynamic | test | - | 500 | 0.516 | 0.686 | 17.000 | 0.358 | 0.431 | pass |
| final/dynamic/test_paper | dynamic | test_paper | - | 500 | 0.496 | 0.646 | 15.000 | 0.388 | 0.366 | pass |
