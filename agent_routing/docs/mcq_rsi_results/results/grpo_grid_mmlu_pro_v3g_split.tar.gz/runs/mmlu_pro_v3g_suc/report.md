# MCQ RSI report: mmlu_pro (main, arms success, R=3)

Stages 16/16 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r1/S1_dev | all | 0.625 | 0.555 | 7.000 | 0.320 | 0.305 | 0.200 | 0.085 | 0.025 | +0/-0 | +0/-0 | 0 | - | - | pass |
| r1/grpo_dev | all | 0.640 | 0.550 | 9.000 | 0.365 | 0.350 | 0.253 | 0.110 | 0.025 | +2/-3 | +5/-2 | 18 | +5/-2 | 18 | valid_answer_rate=0.995 |
| r2/success/sft_dev | success | 0.695 | 0.520 | 17.500 | 0.995 | 0.995 | 0.010 | 0.210 | 0.035 | +4/-11 | +21/-7 | 141 | +21/-7 | 141 | pass |
| r2/success/grpo_dev | success | 0.695 | 0.545 | 15.000 | 0.980 | 0.980 | 0.017 | 0.195 | 0.045 | +6/-8 | +22/-8 | 138 | +8/-8 | 3 | pass |
| r3/success/sft_dev | success | 0.690 | 0.520 | 17.000 | 1.000 | 1.000 | 0.000 | 0.210 | 0.040 | +4/-11 | +22/-9 | 142 | +4/-5 | 4 | pass |
| r3/success/grpo_dev | success | 0.700 | 0.525 | 17.500 | 1.000 | 1.000 | 0.000 | 0.210 | 0.035 | +8/-14 | +23/-8 | 142 | +3/-1 | 0 | pass |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| success: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | True | 0.625 | 0.320 | 0.200 |
| 2 | r2/success/grpo_dev | False | 0.695 | 0.980 | 0.017 |
| 3 | r3/success/grpo_dev | False | 0.700 | 1.000 | 0.000 |

## Recollections (Tables 1-2 analogues)

| stage | n | A0 commit | A1 best 1 call | AD best | Gain@1 | unsolved | E 100Δ | R 100Δ | V 100Δ | policy call rate |
|---|---|---|---|---|---|---|---|---|---|---|
| r2/collect | 400 | 0.525 | 0.772 | 0.792 | 0.925 | 83 | 0.750 | 2.750 | 18.500 | 0.345 |
| r3/success/collect | 400 | 0.480 | 0.797 | 0.820 | 0.934 | 72 | 3.000 | 4.500 | 23.750 | 0.980 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| r2/success/select | success | 578 | 64 | 261 | 253 | 253 | 64 |
| r3/success/select | success | 602 | 63 | 274 | 265 | 265 | 63 |

## FA-GRPO

| stage | lr | steps | selected step | guard ok | informative frac |
|---|---|---|---|---|---|
| r1/grpo | 0.000 | 16 | 8 | False | 0.115 |
| r2/success/grpo | 0.000 | 64 | 64 | True | 0.305 |
| r3/success/grpo | 0.000 | 64 | 64 | True | 0.169 |

## Gates

- r1/S1_dev: parity pass
- r1/grpo_dev: grpo_rejected ["G_k dev eval failed its gate: ['valid_answer_rate=0.995']", 'FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r2/success/grpo_dev: grpo_accepted 
- r3/success/grpo_dev: grpo_accepted 

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/S_1/dev_forced_extractor | S_1 | dev | extractor | 200 | - | 0.525 | - | 1.000 | - | valid_answer_rate=0.995 |
| final/S_1/dev_forced_extractor+reasoner+verifier | S_1 | dev | extractor,reasoner,verifier | 200 | - | 0.675 | - | 3.000 | - | pass |
| final/S_1/dev_forced_reasoner | S_1 | dev | reasoner | 200 | - | 0.575 | - | 1.000 | - | pass |
| final/S_1/dev_forced_verifier | S_1 | dev | verifier | 200 | - | 0.670 | - | 1.000 | - | pass |
| final/S_1/test | S_1 | test | - | 500 | 0.510 | 0.636 | 12.600 | 0.352 | 0.309 | pass |
| final/S_1/test_paper | S_1 | test_paper | - | 500 | 0.492 | 0.596 | 10.400 | 0.348 | 0.265 | pass |
| final/success/dev_forced_extractor | success | dev | extractor | 200 | - | 0.530 | - | 1.000 | - | pass |
| final/success/dev_forced_extractor+reasoner+verifier | success | dev | extractor,reasoner,verifier | 200 | - | 0.680 | - | 3.000 | - | pass |
| final/success/dev_forced_reasoner | success | dev | reasoner | 200 | - | 0.580 | - | 1.000 | - | valid_answer_rate=0.995 |
| final/success/dev_forced_verifier | success | dev | verifier | 200 | - | 0.680 | - | 1.000 | - | pass |
| final/success/test | success | test | - | 500 | 0.530 | 0.718 | 18.800 | 0.996 | 0.008 | pass |
| final/success/test_paper | success | test_paper | - | 500 | 0.488 | 0.690 | 20.200 | 0.996 | 0.000 | pass |
