# Self-check: aqua dev (n=254), checkpoint /workspace/mcq_rsi/import/aqua/round1/sft

draft accuracy 0.390 (matches policy draft 0.996); majority-of-8 accuracy 0.382

| signal | AUROC(draft wrong) | mean when wrong | mean when right |
|---|---|---|---|
| 1-p_max | 0.576 | 0.318 | 0.271 |
| -margin | 0.561 | -0.481 | -0.548 |
| entropy | 0.596 | 0.779 | 0.661 |
| 1-agreement | 0.562 | 0.158 | 0.115 |

policy on dev: acc 0.732 at calls 0.79; always-Verifier 0.772

| simulated router (call Verifier when uncertain) | acc @ calls 0.79 | acc @ calls 0.82 | best (calls, acc) |
|---|---|---|---|
| 1-p_max | 0.709 | 0.724 | 0.976, 0.776 |
| -margin | 0.713 | 0.721 | 0.976, 0.776 |
| entropy | 0.705 | 0.721 | 0.972, 0.776 |
| 1-agreement | 0.701 | 0.693 | 0.996, 0.772 |
