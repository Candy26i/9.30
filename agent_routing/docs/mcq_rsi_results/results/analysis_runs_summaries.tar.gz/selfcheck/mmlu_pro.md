# Self-check: mmlu_pro dev (n=200), checkpoint /workspace/mcq_rsi/import/mmlu_pro/round1/sft

draft accuracy 0.555 (matches policy draft 0.995); majority-of-8 accuracy 0.555

| signal | AUROC(draft wrong) | mean when wrong | mean when right |
|---|---|---|---|
| 1-p_max | 0.473 | 0.138 | 0.168 |
| -margin | 0.467 | -0.749 | -0.689 |
| entropy | 0.487 | 0.390 | 0.416 |
| 1-agreement | 0.602 | 0.157 | 0.063 |

policy on dev: acc 0.625 at calls 0.32; always-Verifier 0.670

| simulated router (call Verifier when uncertain) | acc @ calls 0.32 | acc @ calls 0.22 | best (calls, acc) |
|---|---|---|---|
| 1-p_max | 0.590 | 0.570 | 0.895, 0.675 |
| -margin | 0.580 | 0.565 | 0.9, 0.675 |
| entropy | 0.575 | 0.580 | 0.895, 0.675 |
| 1-agreement | 0.610 | 0.600 | 0.985, 0.680 |
