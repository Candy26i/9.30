# Self-check: gpqa dev (n=100), checkpoint /workspace/mcq_rsi/import/gpqa/round1/sft

draft accuracy 0.410 (matches policy draft 1.000); majority-of-8 accuracy 0.400

| signal | AUROC(draft wrong) | mean when wrong | mean when right |
|---|---|---|---|
| 1-p_max | 0.647 | 0.286 | 0.186 |
| -margin | 0.640 | -0.497 | -0.666 |
| entropy | 0.659 | 0.645 | 0.444 |
| 1-agreement | 0.660 | 0.184 | 0.085 |

policy on dev: acc 0.520 at calls 0.62; always-Verifier 0.520

| simulated router (call Verifier when uncertain) | acc @ calls 0.62 | acc @ calls 0.61 | best (calls, acc) |
|---|---|---|---|
| 1-p_max | 0.490 | 0.480 | 0.92, 0.520 |
| -margin | 0.480 | 0.480 | 0.92, 0.520 |
| entropy | 0.490 | 0.480 | 0.92, 0.520 |
| 1-agreement | 0.510 | 0.510 | 0.75, 0.540 |
