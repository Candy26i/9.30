# Self-check: medqa dev (n=200), checkpoint /workspace/mcq_rsi/import/medqa/round1/sft

draft accuracy 0.705 (matches policy draft 1.000); majority-of-8 accuracy 0.710

| signal | AUROC(draft wrong) | mean when wrong | mean when right |
|---|---|---|---|
| 1-p_max | 0.717 | 0.175 | 0.066 |
| -margin | 0.716 | -0.666 | -0.875 |
| entropy | 0.719 | 0.392 | 0.168 |
| 1-agreement | 0.580 | 0.072 | 0.028 |

policy on dev: acc 0.790 at calls 0.37; always-Verifier 0.865

| simulated router (call Verifier when uncertain) | acc @ calls 0.37 | acc @ calls 0.14 | best (calls, acc) |
|---|---|---|---|
| 1-p_max | 0.825 | 0.755 | 0.865, 0.865 |
| -margin | 0.820 | 0.750 | 0.855, 0.865 |
| entropy | 0.825 | 0.760 | 0.865, 0.865 |
| 1-agreement | 0.775 | 0.760 | 0.97, 0.865 |
