# Label quality by round: mmlu_pro (dev, SFT from S_1, draft_supervision=none)

| labels | SFT rows | acc | draft acc | call rate | calls/ex | call rate (draft wrong) | correction | corruption | valid |
|---|---|---|---|---|---|---|---|---|---|
| S2 | 475 | 0.650 | 0.530 | 0.310 | 0.310 | 0.479 | 0.135 | 0.015 | 1.000 |
| G2 | 464 | 0.650 | 0.530 | 0.280 | 0.280 | 0.457 | 0.125 | 0.005 | 1.000 |
