# Label quality by round: gpqa (dev, SFT from S_1, draft_supervision=none)

| labels | SFT rows | acc | draft acc | call rate | calls/ex | call rate (draft wrong) | correction | corruption | valid |
|---|---|---|---|---|---|---|---|---|---|
| S1 | 210 | 0.540 | 0.430 | 0.610 | 0.610 | 0.667 | 0.140 | 0.030 | 1.000 |
| G1 | 220 | 0.580 | 0.450 | 0.510 | 0.510 | 0.600 | 0.140 | 0.010 | 1.000 |
