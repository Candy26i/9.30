# Label quality by round: gpqa (dev, SFT from S_1, draft_supervision=none)

| labels | SFT rows | acc | draft acc | call rate | calls/ex | call rate (draft wrong) | correction | corruption | valid |
|---|---|---|---|---|---|---|---|---|---|
| S_1 | - | 0.530 | 0.410 | 0.620 | 0.620 | 0.610 | 0.150 | 0.030 | 1.000 |
| r1 | 148 | 0.550 | 0.440 | 0.690 | 0.690 | 0.768 | 0.150 | 0.040 | 1.000 |
| r2 | 210 | 0.530 | 0.400 | 0.620 | 0.620 | 0.650 | 0.150 | 0.020 | 1.000 |
| r3 | 215 | 0.520 | 0.410 | 0.560 | 0.560 | 0.593 | 0.120 | 0.010 | 1.000 |
