# Label quality by round: aqua (dev, SFT from S_1, draft_supervision=none)

| labels | SFT rows | acc | draft acc | call rate | calls/ex | call rate (draft wrong) | correction | corruption | valid |
|---|---|---|---|---|---|---|---|---|---|
| S1 | 561 | 0.724 | 0.378 | 0.772 | 0.772 | 0.810 | 0.362 | 0.016 | 1.000 |
| G1 | 557 | 0.693 | 0.378 | 0.661 | 0.661 | 0.690 | 0.335 | 0.020 | 1.000 |
| S2 | 578 | 0.756 | 0.386 | 0.811 | 0.811 | 0.853 | 0.386 | 0.016 | 1.000 |
| G2 | 596 | 0.744 | 0.386 | 0.846 | 0.846 | 0.872 | 0.382 | 0.024 | 1.000 |
