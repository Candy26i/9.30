# MCQ RSI tables

## table1_oracle_by_depth

| stage | round | n | commit A0 | best 1 call A1 | best measured AD | Gain@1 | unsolved |
|---|---|---|---|---|---|---|---|
| r2/collect | 2 | 200 | 39.000 | 70.500 | 71.500 | 0.969 | 57 |
| r3/dynamic_sft/collect | 3 | 200 | 41.000 | 76.000 | 78.500 | 0.933 | 43 |

## table2_net_marginal_value

| stage | round | extractor 100Δ | reasoner 100Δ | verifier 100Δ |
|---|---|---|---|---|
| r2/collect | 2 | 3.500 | 9.000 | 22.000 |
| r3/dynamic_sft/collect | 3 | 3.500 | 9.000 | 20.500 |

## table3_test

| stage | label | pool | n | candidate | MARGENT | gain pp | calls |
|---|---|---|---|---|---|---|---|
| final/S_1/test | S_1 | test | 100 | 0.410 | 0.540 | 13.000 | 0.520 |
| final/dynamic_sft/test | dynamic_sft | test | 100 | 0.370 | 0.480 | 11.000 | 0.580 |
| final/static_sft/test | static_sft | test | 100 | 0.420 | 0.510 | 9.000 | 0.380 |

## table7_selectivity

| stage | round | candidate | margin | call gap |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.410 | 0.160 | -0.024 |
| r2/dynamic_sft/sft_dev | 2 | 0.390 | 0.140 | 0.075 |
| r2/static_sft/sft_dev | 2 | 0.420 | 0.170 | 0.056 |
| r3/dynamic_sft/sft_dev | 3 | 0.410 | 0.160 | 0.091 |
| r3/static_sft/sft_dev | 3 | 0.400 | 0.150 | 0.192 |

## table8_outcomes

| stage | round | calls | correction | corruption |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.620 | 0.140 | 0.030 |
| r2/dynamic_sft/sft_dev | 2 | 0.610 | 0.160 | 0.050 |
| r2/static_sft/sft_dev | 2 | 0.580 | 0.120 | 0.030 |
| r3/dynamic_sft/sft_dev | 3 | 0.590 | 0.140 | 0.090 |
| r3/static_sft/sft_dev | 3 | 0.440 | 0.110 | 0.040 |

## Paired tests (b - a)

| pool | a | b | n | Δacc | Δacc 95% CI | p | Δcalls | Δcalls 95% CI | McNemar exact p |
|---|---|---|---|---|---|---|---|---|---|
| test | S_1 | dynamic_sft | 100 | -0.060 | [-0.130, 0.010] | 0.129 | 0.060 | [-0.010, 0.140] | 0.180 |
| test | S_1 | static_sft | 100 | -0.030 | [-0.080, 0.020] | 0.328 | -0.140 | [-0.220, -0.070] | 0.453 |

## Matched-budget replay (dev)

| label | n | roles | fixed | policy replay acc | random 95% interval | p | above interval | excluded (broken forced eval: valid rate) |
|---|---|---|---|---|---|---|---|---|
| S_1 | 100 | {"extractor": 0, "reasoner": 16, "verifier": 46} | 0 | 0.470 | [0.420, 0.510] | 0.552 | False | {} |
| dynamic_sft | 100 | {"extractor": 0, "reasoner": 31, "verifier": 28} | 0 | 0.470 | [0.410, 0.510] | 0.401 | False | {} |
| static_sft | 100 | {"extractor": 0, "reasoner": 14, "verifier": 30} | 0 | 0.470 | [0.400, 0.490] | 0.207 | False | {} |
