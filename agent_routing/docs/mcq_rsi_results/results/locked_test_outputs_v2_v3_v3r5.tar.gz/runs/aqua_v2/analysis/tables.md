# MCQ RSI tables

## table1_oracle_by_depth

| stage | round | n | commit A0 | best 1 call A1 | best measured AD | Gain@1 | unsolved |
|---|---|---|---|---|---|---|---|
| r2/collect | 2 | 400 | 41.000 | 88.750 | 90.000 | 0.974 | 40 |
| r3/dynamic_sft/collect | 3 | 400 | 35.750 | 90.750 | 93.250 | 0.957 | 27 |

## table2_net_marginal_value

| stage | round | extractor 100Δ | reasoner 100Δ | verifier 100Δ |
|---|---|---|---|---|
| r2/collect | 2 | -6.750 | 2.250 | 43.750 |
| r3/dynamic_sft/collect | 3 | -0.750 | 5.250 | 49.000 |

## table3_test

| stage | label | pool | n | candidate | MARGENT | gain pp | calls |
|---|---|---|---|---|---|---|---|
| final/S_1/test | S_1 | test | 254 | 0.362 | 0.776 | 41.339 | 0.780 |
| final/dynamic_sft/test | dynamic_sft | test | 254 | 0.370 | 0.827 | 45.669 | 0.890 |
| final/static_sft/test | static_sft | test | 254 | 0.362 | 0.689 | 32.677 | 0.650 |

## table7_selectivity

| stage | round | candidate | margin | call gap |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.394 | 0.194 | 0.148 |
| r2/dynamic_sft/sft_dev | 2 | 0.390 | 0.190 | 0.182 |
| r2/static_sft/sft_dev | 2 | 0.398 | 0.198 | 0.167 |
| r3/dynamic_sft/sft_dev | 3 | 0.370 | 0.170 | 0.099 |
| r3/static_sft/sft_dev | 3 | 0.382 | 0.182 | 0.265 |

## table8_outcomes

| stage | round | calls | correction | corruption |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.791 | 0.362 | 0.024 |
| r2/dynamic_sft/sft_dev | 2 | 0.858 | 0.437 | 0.024 |
| r2/static_sft/sft_dev | 2 | 0.752 | 0.331 | 0.024 |
| r3/dynamic_sft/sft_dev | 3 | 0.917 | 0.469 | 0.039 |
| r3/static_sft/sft_dev | 3 | 0.661 | 0.343 | 0.016 |

## Paired tests (b - a)

| pool | a | b | n | Δacc | Δacc 95% CI | p | Δcalls | Δcalls 95% CI | McNemar exact p |
|---|---|---|---|---|---|---|---|---|---|
| test | S_1 | dynamic_sft | 254 | 0.051 | [0.012, 0.091] | 0.012 | 0.110 | [0.071, 0.154] | 0.019 |
| test | S_1 | static_sft | 254 | -0.087 | [-0.130, -0.047] | 0.000 | -0.130 | [-0.177, -0.087] | 0.000 |

## Matched-budget replay (dev)

| label | n | roles | fixed | policy replay acc | random 95% interval | p | above interval | excluded (broken forced eval: valid rate) |
|---|---|---|---|---|---|---|---|---|
| S_1 | 254 | {"reasoner": 0, "verifier": 198} | 0 | 0.701 | [0.661, 0.717] | 0.238 | False | {"extractor": 0.6377952755905512} |
| dynamic_sft | 254 | {"verifier": 231} | 1 | 0.724 | [0.697, 0.736] | 0.220 | False | {"extractor": 0.8976377952755905, "reasoner": 0.8937007874015748} |
| static_sft | 254 | {"verifier": 160} | 2 | 0.661 | [0.594, 0.657] | 0.024 | True | {"extractor": 0.5393700787401575, "reasoner": 0.7204724409448819} |
