# MCQ RSI tables

## table1_oracle_by_depth

| stage | round | n | commit A0 | best 1 call A1 | best measured AD | Gain@1 | unsolved |
|---|---|---|---|---|---|---|---|
| r2/collect | 2 | 400 | 70.500 | 91.750 | 92.500 | 0.966 | 30 |
| r3/dynamic_sft/collect | 3 | 400 | 75.750 | 93.000 | 94.000 | 0.945 | 24 |

## table2_net_marginal_value

| stage | round | extractor 100Δ | reasoner 100Δ | verifier 100Δ |
|---|---|---|---|---|
| r2/collect | 2 | 7.750 | 14.750 | 12.250 |
| r3/dynamic_sft/collect | 3 | 4.750 | 11.500 | 7.500 |

## table3_test

| stage | label | pool | n | candidate | MARGENT | gain pp | calls |
|---|---|---|---|---|---|---|---|
| final/S_1/test | S_1 | test | 500 | 0.734 | 0.784 | 5.000 | 0.356 |
| final/dynamic_sft/test | dynamic_sft | test | 500 | 0.748 | 0.786 | 3.800 | 0.148 |
| final/static_sft/test | static_sft | test | 500 | 0.756 | 0.786 | 3.000 | 0.270 |

## table7_selectivity

| stage | round | candidate | margin | call gap |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.705 | 0.455 | 0.413 |
| r2/dynamic_sft/sft_dev | 2 | 0.715 | 0.465 | 0.436 |
| r2/static_sft/sft_dev | 2 | 0.725 | 0.475 | 0.332 |
| r3/dynamic_sft/sft_dev | 3 | 0.740 | 0.490 | 0.279 |
| r3/static_sft/sft_dev | 3 | 0.725 | 0.475 | 0.350 |

## table8_outcomes

| stage | round | calls | correction | corruption |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.370 | 0.110 | 0.025 |
| r2/dynamic_sft/sft_dev | 2 | 0.285 | 0.100 | 0.025 |
| r2/static_sft/sft_dev | 2 | 0.250 | 0.075 | 0.020 |
| r3/dynamic_sft/sft_dev | 3 | 0.140 | 0.055 | 0.005 |
| r3/static_sft/sft_dev | 3 | 0.275 | 0.080 | 0.015 |

## Paired tests (b - a)

| pool | a | b | n | Δacc | Δacc 95% CI | p | Δcalls | Δcalls 95% CI | McNemar exact p |
|---|---|---|---|---|---|---|---|---|---|
| test | S_1 | dynamic_sft | 500 | 0.002 | [-0.022, 0.026] | 0.935 | -0.208 | [-0.246, -0.172] | 1.000 |
| test | S_1 | static_sft | 500 | 0.002 | [-0.016, 0.020] | 0.913 | -0.086 | [-0.120, -0.054] | 1.000 |

## Matched-budget replay (dev)

| label | n | roles | fixed | policy replay acc | random 95% interval | p | above interval | excluded (broken forced eval: valid rate) |
|---|---|---|---|---|---|---|---|---|
| S_1 | 200 | {"extractor": 2, "reasoner": 40, "verifier": 32} | 0 | 0.795 | [0.730, 0.785] | 0.012 | True | {} |
| dynamic_sft | 200 | {"extractor": 2, "reasoner": 26, "verifier": 0} | 0 | 0.785 | [0.735, 0.770] | 0.002 | True | {} |
| static_sft | 200 | {"extractor": 3, "reasoner": 22, "verifier": 26} | 0 | 0.785 | [0.730, 0.780] | 0.013 | True | {} |
