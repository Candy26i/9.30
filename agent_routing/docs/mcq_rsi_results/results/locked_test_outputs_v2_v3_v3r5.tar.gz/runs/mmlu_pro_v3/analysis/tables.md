# MCQ RSI tables

## table1_oracle_by_depth

| stage | round | n | commit A0 | best 1 call A1 | best measured AD | Gain@1 | unsolved |
|---|---|---|---|---|---|---|---|
| r2/collect | 2 | 400 | 52.500 | 77.250 | 79.250 | 0.925 | 83 |
| r3/dynamic_sft/collect | 3 | 400 | 46.750 | 77.750 | 79.500 | 0.947 | 82 |

## table2_net_marginal_value

| stage | round | extractor 100Δ | reasoner 100Δ | verifier 100Δ |
|---|---|---|---|---|
| r2/collect | 2 | 1.000 | 2.750 | 18.500 |
| r3/dynamic_sft/collect | 3 | 1.250 | 6.000 | 25.250 |

## table3_test

| stage | label | pool | n | candidate | MARGENT | gain pp | calls |
|---|---|---|---|---|---|---|---|
| final/S_1/test | S_1 | test | 500 | 0.510 | 0.640 | 13.000 | 0.354 |
| final/S_1/test_paper | S_1 | test_paper | 500 | 0.494 | 0.596 | 10.200 | 0.348 |
| final/dynamic_sft/test | dynamic_sft | test | 500 | 0.510 | 0.644 | 13.400 | 0.270 |
| final/dynamic_sft/test_paper | dynamic_sft | test_paper | 500 | 0.478 | 0.598 | 12.000 | 0.274 |
| final/static_sft/test | static_sft | test | 500 | 0.506 | 0.580 | 7.400 | 0.262 |
| final/static_sft/test_paper | static_sft | test_paper | 500 | 0.484 | 0.590 | 10.600 | 0.286 |

## table7_selectivity

| stage | round | candidate | margin | call gap |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.555 | 0.455 | 0.200 |
| r2/dynamic_sft/sft_dev | 2 | 0.525 | 0.425 | 0.081 |
| r2/static_sft/sft_dev | 2 | 0.555 | 0.455 | 0.170 |
| r3/dynamic_sft/sft_dev | 3 | 0.525 | 0.425 | 0.203 |
| r3/static_sft/sft_dev | 3 | 0.540 | 0.440 | 0.214 |

## table8_outcomes

| stage | round | calls | correction | corruption |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.320 | 0.085 | 0.025 |
| r2/dynamic_sft/sft_dev | 2 | 0.105 | 0.045 | 0.010 |
| r2/static_sft/sft_dev | 2 | 0.225 | 0.070 | 0.010 |
| r3/dynamic_sft/sft_dev | 3 | 0.220 | 0.110 | 0.010 |
| r3/static_sft/sft_dev | 3 | 0.290 | 0.080 | 0.015 |

## Paired tests (b - a)

| pool | a | b | n | Δacc | Δacc 95% CI | p | Δcalls | Δcalls 95% CI | McNemar exact p |
|---|---|---|---|---|---|---|---|---|---|
| test | S_1 | dynamic_sft | 500 | 0.004 | [-0.028, 0.036] | 0.839 | -0.084 | [-0.130, -0.038] | 0.902 |
| test | S_1 | static_sft | 500 | -0.060 | [-0.088, -0.034] | 0.000 | -0.092 | [-0.130, -0.056] | 0.000 |
| test_paper | S_1 | dynamic_sft | 500 | 0.002 | [-0.028, 0.032] | 0.965 | -0.074 | [-0.118, -0.030] | 1.000 |
| test_paper | S_1 | static_sft | 500 | -0.006 | [-0.028, 0.016] | 0.654 | -0.062 | [-0.098, -0.028] | 0.728 |

## Matched-budget replay (dev)

| label | n | roles | fixed | policy replay acc | random 95% interval | p | above interval | excluded (broken forced eval: valid rate) |
|---|---|---|---|---|---|---|---|---|
| S_1 | 200 | {"extractor": 2, "reasoner": 7, "verifier": 52} | 0 | 0.585 | [0.555, 0.620] | 0.587 | False | {} |
| dynamic_sft | 200 | {"extractor": 0, "reasoner": 3, "verifier": 41} | 0 | 0.580 | [0.530, 0.585] | 0.096 | False | {} |
| static_sft | 200 | {"extractor": 8, "reasoner": 4, "verifier": 41} | 0 | 0.565 | [0.535, 0.595] | 0.599 | False | {} |
