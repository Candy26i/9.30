# MCQ RSI report: medqa (main, arms dynamic_sft, static_sft, R=5)

Stages 16/16 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

Continuation of /workspace/mcq_rsi/runs/medqa_v3 from round 3 (source git 9478cd2f819a6fb383c800f776098ec08d9c8e1d, signature 5e2e45c83c4a); G_3: dynamic_sft r3/dynamic_sft/sft_dev (adapter 9844e9f3e63a); static_sft r3/static_sft/sft_dev (adapter 6dfac3d68aa6). No S_1 final; drift vs S_1 uses the source run's r1/S1_dev.

## Split caveats (extended manifest)

- grpo_r4: drawn from the fresh-question population, not the paper GRPO pool of grpo_r1..r3 (exhausted): the GRPO pool composition changes at the round-3/4 boundary (advisor-SFT questions: base grpo_r1 89 / grpo_r2 92 / grpo_r3 76; extended grpo_r4 6 / grpo_r5 2 (of 256 each)). Rounds 4.. are not like-for-like with rounds 1-3; split GRPO/dev comparisons across that boundary by advisor-SFT membership
- grpo_r5: drawn from the fresh-question population, not the paper GRPO pool of grpo_r1..r3 (exhausted): the GRPO pool composition changes at the round-3/4 boundary (advisor-SFT questions: base grpo_r1 89 / grpo_r2 92 / grpo_r3 76; extended grpo_r4 6 / grpo_r5 2 (of 256 each)). Rounds 4.. are not like-for-like with rounds 1-3; split GRPO/dev comparisons across that boundary by advisor-SFT membership

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/sft_dev | dynamic_sft | 0.795 | 0.740 | 5.500 | 0.150 | 0.150 | 0.265 | 0.060 | 0.005 | +11/-4 | +10/-9 | 56 | +5/-4 | 16 | pass |
| r4/static_sft/sft_dev | static_sft | 0.805 | 0.725 | 8.000 | 0.350 | 0.300 | 0.439 | 0.100 | 0.020 | +6/-2 | +6/-3 | 41 | +5/-3 | 21 | ACKNOWLEDGED: valid_answer_rate=0.995 |
| r5/dynamic_sft/sft_dev | dynamic_sft | 0.760 | 0.740 | 2.000 | 0.175 | 0.175 | 0.257 | 0.040 | 0.020 | +8/-1 | +5/-11 | 57 | +2/-9 | 23 | pass |
| r5/static_sft/sft_dev | static_sft | 0.805 | 0.700 | 10.500 | 0.435 | 0.380 | 0.410 | 0.125 | 0.020 | +4/-5 | +7/-4 | 34 | +3/-3 | 28 | ACKNOWLEDGED: valid_answer_rate=0.995 |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| dynamic_sft: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 3 | r3/dynamic_sft/source | False | 0.790 | 0.140 | 0.279 |
| 4 | r4/dynamic_sft/sft_dev | False | 0.795 | 0.150 | 0.265 |
| 5 | r5/dynamic_sft/sft_dev | False | 0.760 | 0.175 | 0.257 |

| static_sft: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 3 | r3/static_sft/source | False | 0.795 | 0.275 | 0.350 |
| 4 | r4/static_sft/sft_dev | False | 0.805 | 0.350 | 0.439 |
| 5 | r5/static_sft/sft_dev | False | 0.805 | 0.435 | 0.410 |

## Recollections (Tables 1-2 analogues)

| stage | n | A0 commit | A1 best 1 call | AD best | Gain@1 | unsolved | E 100Δ | R 100Δ | V 100Δ | policy call rate |
|---|---|---|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/collect | 400 | 0.745 | 0.897 | 0.905 | 0.953 | 38 | 2.000 | 9.500 | 10.500 | 0.155 |
| r5/dynamic_sft/collect | 400 | 0.767 | 0.922 | 0.927 | 0.969 | 29 | 6.250 | 9.500 | 10.250 | 0.135 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/select | dynamic | 323 | 192 | 67 | 64 | 64 | 192 |
| static/select | static | 315 | - | - | - | - | - |
| r5/dynamic_sft/select | dynamic | 322 | 192 | 66 | 64 | 64 | 192 |

## Gates

- r4/static_sft/sft_dev: eval gate ['valid_answer_rate=0.995'] passed on an acknowledgement (Pre-acknowledged per the user delegation of 2026-10-07: only a validity-rate gate failure (unparsed answers, valid >= ACK_MIN_VALID 0.99) may pass; any other failure still stops the run.)
- r5/dynamic_sft/sft_dev: SFT flags ['accuracy 0.7600 dropped > 0.03 from 0.7950']
- r5/static_sft/sft_dev: eval gate ['valid_answer_rate=0.995'] passed on an acknowledgement (Pre-acknowledged per the user delegation of 2026-10-07: only a validity-rate gate failure (unparsed answers, valid >= ACK_MIN_VALID 0.99) may pass; any other failure still stops the run.)

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/dynamic_sft/dev_forced_extractor | dynamic_sft | dev | extractor | 200 | - | 0.770 | - | 1.000 | - | valid_answer_rate=0.985 |
| final/dynamic_sft/dev_forced_extractor+reasoner+verifier | dynamic_sft | dev | extractor,reasoner,verifier | 200 | - | 0.850 | - | 3.000 | - | pass |
| final/dynamic_sft/dev_forced_reasoner | dynamic_sft | dev | reasoner | 200 | - | 0.845 | - | 1.000 | - | valid_answer_rate=0.995 |
| final/dynamic_sft/dev_forced_verifier | dynamic_sft | dev | verifier | 200 | - | 0.860 | - | 1.000 | - | pass |
| final/dynamic_sft/test | dynamic_sft | test | - | 500 | 0.734 | 0.774 | 4.000 | 0.172 | 0.291 | pass |
| final/static_sft/dev_forced_extractor | static_sft | dev | extractor | 200 | - | 0.755 | - | 1.000 | - | valid_answer_rate=0.92 |
| final/static_sft/dev_forced_extractor+reasoner+verifier | static_sft | dev | extractor,reasoner,verifier | 200 | - | 0.850 | - | 3.000 | - | pass |
| final/static_sft/dev_forced_reasoner | static_sft | dev | reasoner | 200 | - | 0.820 | - | 1.000 | - | valid_answer_rate=0.975 |
| final/static_sft/dev_forced_verifier | static_sft | dev | verifier | 200 | - | 0.850 | - | 1.000 | - | valid_answer_rate=0.985 |
| final/static_sft/test | static_sft | test | - | 500 | 0.746 | 0.810 | 6.400 | 0.368 | 0.410 | pass |
