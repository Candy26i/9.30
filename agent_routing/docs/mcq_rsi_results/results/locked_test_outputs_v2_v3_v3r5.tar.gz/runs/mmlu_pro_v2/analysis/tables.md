# MCQ RSI tables

## table1_oracle_by_depth

| stage | round | n | commit A0 | best 1 call A1 | best measured AD | Gain@1 | unsolved |
|---|---|---|---|---|---|---|---|
| r2/collect | 2 | 400 | 52.500 | 77.250 | 79.250 | 0.925 | 83 |
| r3/dynamic_sft/collect | 3 | 400 | 49.000 | 80.000 | 82.000 | 0.939 | 72 |

## table2_net_marginal_value

| stage | round | extractor 100Δ | reasoner 100Δ | verifier 100Δ |
|---|---|---|---|---|
| r2/collect | 2 | 1.000 | 2.750 | 18.500 |
| r3/dynamic_sft/collect | 3 | 1.750 | 2.000 | 22.750 |

## table3_test

| stage | label | pool | n | candidate | MARGENT | gain pp | calls |
|---|---|---|---|---|---|---|---|
| final/S_1/test | S_1 | test | 500 | 0.510 | 0.640 | 13.000 | 0.354 |
| final/S_1/test_paper | S_1 | test_paper | 500 | 0.494 | 0.596 | 10.200 | 0.348 |
| final/dynamic_sft/test | dynamic_sft | test | 500 | 0.512 | 0.606 | 9.400 | 0.236 |
| final/dynamic_sft/test_paper | dynamic_sft | test_paper | 500 | 0.492 | 0.572 | 8.000 | 0.232 |
| final/static_sft/test | static_sft | test | 500 | 0.510 | 0.590 | 8.000 | 0.284 |
| final/static_sft/test_paper | static_sft | test_paper | 500 | 0.500 | 0.570 | 7.000 | 0.306 |

## table7_selectivity

| stage | round | candidate | margin | call gap |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.555 | 0.455 | 0.200 |
| r2/dynamic_sft/sft_dev | 2 | 0.545 | 0.445 | 0.053 |
| r2/static_sft/sft_dev | 2 | 0.555 | 0.455 | 0.150 |
| r3/dynamic_sft/sft_dev | 3 | 0.550 | 0.450 | 0.173 |
| r3/static_sft/sft_dev | 3 | 0.565 | 0.465 | 0.149 |

## table8_outcomes

| stage | round | calls | correction | corruption |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.320 | 0.085 | 0.025 |
| r2/dynamic_sft/sft_dev | 2 | 0.070 | 0.030 | 0.020 |
| r2/static_sft/sft_dev | 2 | 0.285 | 0.065 | 0.020 |
| r3/dynamic_sft/sft_dev | 3 | 0.205 | 0.085 | 0.030 |
| r3/static_sft/sft_dev | 3 | 0.325 | 0.070 | 0.025 |

## Paired tests (b - a)

| pool | a | b | n | Δacc | Δacc 95% CI | p | Δcalls | Δcalls 95% CI | McNemar exact p |
|---|---|---|---|---|---|---|---|---|---|
| test | S_1 | dynamic_sft | 500 | -0.034 | [-0.064, -0.004] | 0.030 | -0.118 | [-0.160, -0.076] | 0.040 |
| test | S_1 | static_sft | 500 | -0.050 | [-0.076, -0.024] | 0.000 | -0.070 | [-0.108, -0.032] | 0.000 |
| test_paper | S_1 | dynamic_sft | 500 | -0.024 | [-0.058, 0.010] | 0.174 | -0.116 | [-0.158, -0.074] | 0.201 |
| test_paper | S_1 | static_sft | 500 | -0.026 | [-0.052, 0.000] | 0.059 | -0.042 | [-0.080, -0.004] | 0.072 |

## Matched-budget replay (dev)

| label | n | roles | fixed | policy replay acc | random 95% interval | p | above interval | excluded (broken forced eval: valid rate) |
|---|---|---|---|---|---|---|---|---|
| S_1 | 200 | {"extractor": 2, "reasoner": 7, "verifier": 52} | 0 | 0.585 | [0.555, 0.620] | 0.587 | False | {} |
| dynamic_sft | 200 | {"extractor": 6, "reasoner": 3, "verifier": 32} | 0 | 0.585 | [0.545, 0.600] | 0.204 | False | {} |
| static_sft | 200 | {"extractor": 6, "reasoner": 8, "verifier": 45} | 0 | 0.595 | [0.555, 0.620] | 0.422 | False | {} |
