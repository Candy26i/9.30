# MCQ RSI tables

## table1_oracle_by_depth

| stage | round | n | commit A0 | best 1 call A1 | best measured AD | Gain@1 | unsolved |
|---|---|---|---|---|---|---|---|
| r2/collect | 2 | 200 | 39.000 | 70.500 | 71.500 | 0.969 | 57 |
| r3/dynamic_sft/collect | 3 | 200 | 39.000 | 69.500 | 72.000 | 0.924 | 56 |

## table2_net_marginal_value

| stage | round | extractor 100Δ | reasoner 100Δ | verifier 100Δ |
|---|---|---|---|---|
| r2/collect | 2 | 3.500 | 9.000 | 22.000 |
| r3/dynamic_sft/collect | 3 | 3.000 | 8.000 | 21.500 |

## table3_test

| stage | label | pool | n | candidate | MARGENT | gain pp | calls |
|---|---|---|---|---|---|---|---|
| final/S_1/test | S_1 | test | 100 | 0.410 | 0.540 | 13.000 | 0.520 |
| final/dynamic_sft/test | dynamic_sft | test | 100 | 0.410 | 0.540 | 13.000 | 0.580 |
| final/static_sft/test | static_sft | test | 100 | 0.420 | 0.550 | 13.000 | 0.490 |

## table7_selectivity

| stage | round | candidate | margin | call gap |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.410 | 0.160 | -0.024 |
| r2/dynamic_sft/sft_dev | 2 | 0.440 | 0.190 | 0.075 |
| r2/static_sft/sft_dev | 2 | 0.440 | 0.190 | 0.219 |
| r3/dynamic_sft/sft_dev | 3 | 0.420 | 0.170 | 0.067 |
| r3/static_sft/sft_dev | 3 | 0.450 | 0.200 | 0.006 |

## table8_outcomes

| stage | round | calls | correction | corruption |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.620 | 0.140 | 0.030 |
| r2/dynamic_sft/sft_dev | 2 | 0.610 | 0.130 | 0.020 |
| r2/static_sft/sft_dev | 2 | 0.600 | 0.140 | 0.040 |
| r3/dynamic_sft/sft_dev | 3 | 0.610 | 0.140 | 0.030 |
| r3/static_sft/sft_dev | 3 | 0.470 | 0.110 | 0.050 |

## Paired tests (b - a)

| pool | a | b | n | Δacc | Δacc 95% CI | p | Δcalls | Δcalls 95% CI | McNemar exact p |
|---|---|---|---|---|---|---|---|---|---|
| test | S_1 | dynamic_sft | 100 | 0.000 | [-0.060, 0.050] | 1.000 | 0.060 | [0.000, 0.130] | 1.000 |
| test | S_1 | static_sft | 100 | 0.010 | [-0.020, 0.050] | 0.790 | -0.030 | [-0.100, 0.030] | 1.000 |

## Matched-budget replay (dev)

| label | n | roles | fixed | policy replay acc | random 95% interval | p | above interval | excluded (broken forced eval: valid rate) |
|---|---|---|---|---|---|---|---|---|
| S_1 | 100 | {"extractor": 0, "reasoner": 16, "verifier": 46} | 0 | 0.470 | [0.420, 0.510] | 0.552 | False | {} |
| dynamic_sft | 100 | {"extractor": 0, "reasoner": 26, "verifier": 35} | 0 | 0.460 | [0.410, 0.510] | 0.547 | False | {} |
| static_sft | 100 | {"extractor": 0, "reasoner": 13, "verifier": 34} | 0 | 0.470 | [0.430, 0.520] | 0.682 | False | {} |
