# MCQ RSI report: aqua (main, arms dynamic_sft, static_sft, R=5)

Stages 16/16 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

Continuation of /workspace/mcq_rsi/runs/aqua_v3 from round 3 (source git 9478cd2f819a6fb383c800f776098ec08d9c8e1d, signature 9395ace0c3fc); G_3: dynamic_sft r3/dynamic_sft/sft_dev (adapter 49110ec3bdac); static_sft r3/static_sft/sft_dev (adapter 774d6f011723). No S_1 final; drift vs S_1 uses the source run's r1/S1_dev.

## Split caveats (extended manifest)

- grpo_r4: drawn from the fresh-question population, not the paper GRPO pool of grpo_r1..r3 (exhausted): the GRPO pool composition changes at the round-3/4 boundary (advisor-SFT questions: base grpo_r1 55 / grpo_r2 64 / grpo_r3 71; extended grpo_r4 0 / grpo_r5 0 (of 256 each)). Rounds 4.. are not like-for-like with rounds 1-3; split GRPO/dev comparisons across that boundary by advisor-SFT membership
- grpo_r5: drawn from the fresh-question population, not the paper GRPO pool of grpo_r1..r3 (exhausted): the GRPO pool composition changes at the round-3/4 boundary (advisor-SFT questions: base grpo_r1 55 / grpo_r2 64 / grpo_r3 71; extended grpo_r4 0 / grpo_r5 0 (of 256 each)). Rounds 4.. are not like-for-like with rounds 1-3; split GRPO/dev comparisons across that boundary by advisor-SFT membership

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/sft_dev | dynamic_sft | 0.709 | 0.343 | 36.614 | 0.724 | 0.724 | 0.210 | 0.386 | 0.020 | +5/-18 | +11/-17 | 48 | +5/-22 | 54 | pass |
| r4/static_sft/sft_dev | static_sft | 0.748 | 0.378 | 37.008 | 0.780 | 0.764 | 0.223 | 0.386 | 0.016 | +6/-10 | +11/-7 | 28 | +7/-3 | 16 | pass |
| r5/dynamic_sft/sft_dev | dynamic_sft | 0.724 | 0.398 | 32.677 | 0.740 | 0.740 | 0.259 | 0.354 | 0.028 | +13/-12 | +18/-20 | 62 | +13/-9 | 46 | pass |
| r5/static_sft/sft_dev | static_sft | 0.756 | 0.386 | 37.008 | 0.807 | 0.760 | 0.274 | 0.390 | 0.020 | +8/-10 | +13/-7 | 36 | +4/-2 | 15 | pass |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| dynamic_sft: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 3 | r3/dynamic_sft/source | False | 0.776 | 0.819 | 0.240 |
| 4 | r4/dynamic_sft/sft_dev | False | 0.709 | 0.724 | 0.210 |
| 5 | r5/dynamic_sft/sft_dev | False | 0.724 | 0.740 | 0.259 |

| static_sft: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 3 | r3/static_sft/source | False | 0.732 | 0.724 | 0.252 |
| 4 | r4/static_sft/sft_dev | False | 0.748 | 0.780 | 0.223 |
| 5 | r5/static_sft/sft_dev | False | 0.756 | 0.807 | 0.274 |

## Recollections (Tables 1-2 analogues)

| stage | n | A0 commit | A1 best 1 call | AD best | Gain@1 | unsolved | E 100Δ | R 100Δ | V 100Δ | policy call rate |
|---|---|---|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/collect | 400 | 0.400 | 0.907 | 0.917 | 0.981 | 33 | -2.000 | 2.000 | 46.000 | 0.770 |
| r5/dynamic_sft/collect | 400 | 0.372 | 0.895 | 0.920 | 0.954 | 32 | -1.000 | 4.250 | 48.000 | 0.660 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/select | dynamic | 578 | 160 | 211 | 207 | 207 | 160 |
| static/select | static | 402 | - | - | - | - | - |
| r5/dynamic_sft/select | dynamic | 597 | 149 | 229 | 219 | 219 | 149 |

## Gates

- r4/dynamic_sft/sft_dev: SFT flags ['accuracy 0.7087 dropped > 0.03 from 0.7756']

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/dynamic_sft/dev_forced_extractor | dynamic_sft | dev | extractor | 254 | - | 0.311 | - | 1.000 | - | BROKEN: valid_answer_rate=0.7125984251968503 |
| final/dynamic_sft/dev_forced_extractor+reasoner+verifier | dynamic_sft | dev | extractor,reasoner,verifier | 254 | - | 0.780 | - | 3.000 | - | pass |
| final/dynamic_sft/dev_forced_reasoner | dynamic_sft | dev | reasoner | 254 | - | 0.299 | - | 1.000 | - | BROKEN: valid_answer_rate=0.6732283464566929 |
| final/dynamic_sft/dev_forced_verifier | dynamic_sft | dev | verifier | 254 | - | 0.756 | - | 1.000 | - | valid_answer_rate=0.9921259842519685 |
| final/dynamic_sft/test | dynamic_sft | test | - | 254 | 0.370 | 0.717 | 34.646 | 0.720 | 0.192 | pass |
| final/static_sft/dev_forced_extractor | static_sft | dev | extractor | 254 | - | 0.189 | - | 1.000 | - | BROKEN: valid_answer_rate=0.3464566929133858 |
| final/static_sft/dev_forced_extractor+reasoner+verifier | static_sft | dev | extractor,reasoner,verifier | 254 | - | 0.776 | - | 3.000 | - | valid_answer_rate=0.9960629921259843 |
| final/static_sft/dev_forced_reasoner | static_sft | dev | reasoner | 254 | - | 0.323 | - | 1.000 | - | BROKEN: valid_answer_rate=0.6850393700787402 |
| final/static_sft/dev_forced_verifier | static_sft | dev | verifier | 254 | - | 0.780 | - | 1.000 | - | valid_answer_rate=0.984251968503937 |
| final/static_sft/test | static_sft | test | - | 254 | 0.374 | 0.772 | 39.764 | 0.764 | 0.302 | pass |
