# MCQ RSI tables

## table1_oracle_by_depth

| stage | round | n | commit A0 | best 1 call A1 | best measured AD | Gain@1 | unsolved |
|---|---|---|---|---|---|---|---|
| r2/collect | 2 | 400 | 41.000 | 88.750 | 90.000 | 0.974 | 40 |
| r3/dynamic_sft/collect | 3 | 400 | 37.250 | 88.500 | 89.500 | 0.981 | 42 |

## table2_net_marginal_value

| stage | round | extractor 100Δ | reasoner 100Δ | verifier 100Δ |
|---|---|---|---|---|
| r2/collect | 2 | -6.750 | 2.250 | 43.750 |
| r3/dynamic_sft/collect | 3 | -1.000 | 0.250 | 48.250 |

## table3_test

| stage | label | pool | n | candidate | MARGENT | gain pp | calls |
|---|---|---|---|---|---|---|---|
| final/S_1/test | S_1 | test | 254 | 0.362 | 0.776 | 41.339 | 0.780 |
| final/dynamic_sft/test | dynamic_sft | test | 254 | 0.350 | 0.780 | 42.913 | 0.791 |
| final/static_sft/test | static_sft | test | 254 | 0.386 | 0.748 | 36.220 | 0.728 |

## table7_selectivity

| stage | round | candidate | margin | call gap |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.394 | 0.194 | 0.148 |
| r2/dynamic_sft/sft_dev | 2 | 0.374 | 0.174 | 0.112 |
| r2/static_sft/sft_dev | 2 | 0.390 | 0.190 | 0.183 |
| r3/dynamic_sft/sft_dev | 3 | 0.350 | 0.150 | 0.240 |
| r3/static_sft/sft_dev | 3 | 0.378 | 0.178 | 0.252 |

## table8_outcomes

| stage | round | calls | correction | corruption |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.791 | 0.362 | 0.024 |
| r2/dynamic_sft/sft_dev | 2 | 0.807 | 0.390 | 0.016 |
| r2/static_sft/sft_dev | 2 | 0.752 | 0.354 | 0.020 |
| r3/dynamic_sft/sft_dev | 3 | 0.819 | 0.437 | 0.012 |
| r3/static_sft/sft_dev | 3 | 0.724 | 0.370 | 0.016 |

## Paired tests (b - a)

| pool | a | b | n | Δacc | Δacc 95% CI | p | Δcalls | Δcalls 95% CI | McNemar exact p |
|---|---|---|---|---|---|---|---|---|---|
| test | S_1 | dynamic_sft | 254 | 0.004 | [-0.035, 0.043] | 0.928 | 0.012 | [-0.043, 0.067] | 1.000 |
| test | S_1 | static_sft | 254 | -0.028 | [-0.059, 0.004] | 0.100 | -0.051 | [-0.094, -0.008] | 0.143 |

## Matched-budget replay (dev)

| label | n | roles | fixed | policy replay acc | random 95% interval | p | above interval | excluded (broken forced eval: valid rate) |
|---|---|---|---|---|---|---|---|---|
| S_1 | 254 | {"reasoner": 0, "verifier": 198} | 0 | 0.701 | [0.661, 0.717] | 0.238 | False | {"extractor": 0.6377952755905512} |
| dynamic_sft | 254 | {"extractor": 0, "reasoner": 0, "verifier": 208} | 0 | 0.717 | [0.669, 0.720] | 0.080 | False | {} |
| static_sft | 254 | {"verifier": 180} | 0 | 0.701 | [0.634, 0.693] | 0.011 | True | {"extractor": 0.6259842519685039, "reasoner": 0.8110236220472441} |
