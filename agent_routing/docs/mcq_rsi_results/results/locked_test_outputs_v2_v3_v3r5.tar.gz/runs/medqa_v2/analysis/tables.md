# MCQ RSI tables

## table1_oracle_by_depth

| stage | round | n | commit A0 | best 1 call A1 | best measured AD | Gain@1 | unsolved |
|---|---|---|---|---|---|---|---|
| r2/collect | 2 | 400 | 70.500 | 91.750 | 92.500 | 0.966 | 30 |
| r3/dynamic_sft/collect | 3 | 400 | 76.250 | 92.750 | 94.000 | 0.930 | 24 |

## table2_net_marginal_value

| stage | round | extractor 100Δ | reasoner 100Δ | verifier 100Δ |
|---|---|---|---|---|
| r2/collect | 2 | 7.750 | 14.750 | 12.250 |
| r3/dynamic_sft/collect | 3 | 5.000 | 10.500 | 7.000 |

## table3_test

| stage | label | pool | n | candidate | MARGENT | gain pp | calls |
|---|---|---|---|---|---|---|---|
| final/S_1/test | S_1 | test | 500 | 0.734 | 0.784 | 5.000 | 0.356 |
| final/dynamic_sft/test | dynamic_sft | test | 500 | 0.732 | 0.778 | 4.600 | 0.248 |
| final/static_sft/test | static_sft | test | 500 | 0.748 | 0.798 | 5.000 | 0.300 |

## table7_selectivity

| stage | round | candidate | margin | call gap |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.705 | 0.455 | 0.413 |
| r2/dynamic_sft/sft_dev | 2 | 0.715 | 0.465 | 0.429 |
| r2/static_sft/sft_dev | 2 | 0.710 | 0.460 | 0.365 |
| r3/dynamic_sft/sft_dev | 3 | 0.725 | 0.475 | 0.339 |
| r3/static_sft/sft_dev | 3 | 0.710 | 0.460 | 0.406 |

## table8_outcomes

| stage | round | calls | correction | corruption |
|---|---|---|---|---|
| r1/S1_dev | 1 | 0.370 | 0.110 | 0.025 |
| r2/dynamic_sft/sft_dev | 2 | 0.290 | 0.105 | 0.020 |
| r2/static_sft/sft_dev | 2 | 0.280 | 0.095 | 0.020 |
| r3/dynamic_sft/sft_dev | 3 | 0.245 | 0.080 | 0.015 |
| r3/static_sft/sft_dev | 3 | 0.340 | 0.105 | 0.020 |

## Paired tests (b - a)

| pool | a | b | n | Δacc | Δacc 95% CI | p | Δcalls | Δcalls 95% CI | McNemar exact p |
|---|---|---|---|---|---|---|---|---|---|
| test | S_1 | dynamic_sft | 500 | -0.006 | [-0.032, 0.020] | 0.712 | -0.108 | [-0.144, -0.074] | 0.761 |
| test | S_1 | static_sft | 500 | 0.014 | [-0.004, 0.032] | 0.154 | -0.056 | [-0.088, -0.026] | 0.189 |

## Matched-budget replay (dev)

| label | n | roles | fixed | policy replay acc | random 95% interval | p | above interval | excluded (broken forced eval: valid rate) |
|---|---|---|---|---|---|---|---|---|
| S_1 | 200 | {"extractor": 2, "reasoner": 40, "verifier": 32} | 0 | 0.795 | [0.730, 0.785] | 0.012 | True | {} |
| dynamic_sft | 200 | {"extractor": 15, "reasoner": 34, "verifier": 0} | 0 | 0.785 | [0.730, 0.775] | 0.004 | True | {} |
| static_sft | 200 | {"extractor": 5, "reasoner": 23, "verifier": 35} | 0 | 0.780 | [0.720, 0.775] | 0.021 | True | {} |
