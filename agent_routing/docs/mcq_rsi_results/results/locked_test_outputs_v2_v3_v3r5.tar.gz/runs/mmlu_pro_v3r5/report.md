# MCQ RSI report: mmlu_pro (main, arms dynamic_sft, static_sft, R=5)

Stages 16/16 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

Continuation of /workspace/mcq_rsi/runs/mmlu_pro_v3 from round 3 (source git 9478cd2f819a6fb383c800f776098ec08d9c8e1d, signature f47082f6277d); G_3: dynamic_sft r3/dynamic_sft/sft_dev (adapter d3ab8ef3c847); static_sft r3/static_sft/sft_dev (adapter 63a2fa6a6d7a). No S_1 final; drift vs S_1 uses the source run's r1/S1_dev.

## Split caveats (extended manifest)

- grpo_r4: drawn from the fresh-question population, not the paper GRPO pool of grpo_r1..r3 (exhausted): the GRPO pool composition changes at the round-3/4 boundary (advisor-SFT questions: base grpo_r1 55 / grpo_r2 59 / grpo_r3 50; extended grpo_r4 4 / grpo_r5 3 (of 256 each)). Rounds 4.. are not like-for-like with rounds 1-3; split GRPO/dev comparisons across that boundary by advisor-SFT membership
- grpo_r5: drawn from the fresh-question population, not the paper GRPO pool of grpo_r1..r3 (exhausted): the GRPO pool composition changes at the round-3/4 boundary (advisor-SFT questions: base grpo_r1 55 / grpo_r2 59 / grpo_r3 50; extended grpo_r4 4 / grpo_r5 3 (of 256 each)). Rounds 4.. are not like-for-like with rounds 1-3; split GRPO/dev comparisons across that boundary by advisor-SFT membership

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/sft_dev | dynamic_sft | 0.615 | 0.520 | 9.500 | 0.235 | 0.230 | 0.199 | 0.110 | 0.015 | +6/-13 | +12/-14 | 57 | +8/-10 | 21 | pass |
| r4/static_sft/sft_dev | static_sft | 0.600 | 0.550 | 5.000 | 0.310 | 0.290 | 0.119 | 0.075 | 0.025 | +6/-7 | +8/-13 | 37 | +8/-10 | 27 | pass |
| r5/dynamic_sft/sft_dev | dynamic_sft | 0.615 | 0.530 | 8.500 | 0.290 | 0.270 | 0.253 | 0.105 | 0.020 | +7/-12 | +12/-14 | 60 | +5/-5 | 21 | pass |
| r5/static_sft/sft_dev | static_sft | 0.560 | 0.550 | 1.000 | 0.235 | 0.195 | 0.110 | 0.045 | 0.035 | +5/-6 | +6/-19 | 50 | +5/-13 | 32 | pass |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| dynamic_sft: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 3 | r3/dynamic_sft/source | False | 0.625 | 0.220 | 0.203 |
| 4 | r4/dynamic_sft/sft_dev | False | 0.615 | 0.235 | 0.199 |
| 5 | r5/dynamic_sft/sft_dev | False | 0.615 | 0.290 | 0.253 |

| static_sft: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 3 | r3/static_sft/source | False | 0.610 | 0.290 | 0.214 |
| 4 | r4/static_sft/sft_dev | False | 0.600 | 0.310 | 0.119 |
| 5 | r5/static_sft/sft_dev | False | 0.560 | 0.235 | 0.110 |

## Recollections (Tables 1-2 analogues)

| stage | n | A0 commit | A1 best 1 call | AD best | Gain@1 | unsolved | E 100Δ | R 100Δ | V 100Δ | policy call rate |
|---|---|---|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/collect | 400 | 0.495 | 0.782 | 0.805 | 0.927 | 78 | 1.250 | 5.500 | 22.750 | 0.275 |
| r5/dynamic_sft/collect | 400 | 0.497 | 0.810 | 0.833 | 0.933 | 67 | 1.250 | 8.250 | 23.750 | 0.312 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| r4/dynamic_sft/select | dynamic | 455 | 198 | 133 | 124 | 124 | 198 |
| static/select | static | 331 | - | - | - | - | - |
| r5/dynamic_sft/select | dynamic | 476 | 199 | 143 | 134 | 134 | 199 |

## Gates

- r5/static_sft/sft_dev: SFT flags ['accuracy 0.5600 dropped > 0.03 from 0.6000']

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/dynamic_sft/dev_forced_extractor | dynamic_sft | dev | extractor | 200 | - | 0.520 | - | 1.000 | - | BROKEN: valid_answer_rate=0.88 |
| final/dynamic_sft/dev_forced_extractor+reasoner+verifier | dynamic_sft | dev | extractor,reasoner,verifier | 200 | - | 0.685 | - | 3.000 | - | valid_answer_rate=0.995 |
| final/dynamic_sft/dev_forced_reasoner | dynamic_sft | dev | reasoner | 200 | - | 0.570 | - | 1.000 | - | valid_answer_rate=0.95 |
| final/dynamic_sft/dev_forced_verifier | dynamic_sft | dev | verifier | 200 | - | 0.675 | - | 1.000 | - | valid_answer_rate=0.995 |
| final/dynamic_sft/test | dynamic_sft | test | - | 500 | 0.512 | 0.614 | 10.200 | 0.298 | 0.350 | pass |
| final/dynamic_sft/test_paper | dynamic_sft | test_paper | - | 500 | 0.484 | 0.586 | 10.200 | 0.294 | 0.294 | pass |
| final/static_sft/dev_forced_extractor | static_sft | dev | extractor | 200 | - | 0.525 | - | 1.000 | - | valid_answer_rate=0.94 |
| final/static_sft/dev_forced_extractor+reasoner+verifier | static_sft | dev | extractor,reasoner,verifier | 200 | - | 0.680 | - | 3.000 | - | pass |
| final/static_sft/dev_forced_reasoner | static_sft | dev | reasoner | 200 | - | 0.560 | - | 1.000 | - | pass |
| final/static_sft/dev_forced_verifier | static_sft | dev | verifier | 200 | - | 0.660 | - | 1.000 | - | pass |
| final/static_sft/test | static_sft | test | - | 500 | 0.506 | 0.580 | 7.400 | 0.252 | 0.233 | pass |
| final/static_sft/test_paper | static_sft | test_paper | - | 500 | 0.492 | 0.538 | 4.600 | 0.262 | 0.209 | pass |
