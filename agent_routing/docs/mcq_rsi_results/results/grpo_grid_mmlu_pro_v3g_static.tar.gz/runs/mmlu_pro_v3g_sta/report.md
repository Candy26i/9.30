# MCQ RSI report: mmlu_pro (main, arms static, R=3)

Stages 13/13 complete. one seed per cell; dev is used for gates only; the locked test runs once (final-test).

## Dev evaluations (per round)

Drift vs S_1 and vs the previous checkpoint (S_k vs G_(k-1), G_k vs S_k) on the same dev ids.

| stage | arms | acc | candidate | gain pp | calls | call rate | call gap | correction | corruption | S_1 drift cand +/- | S_1 drift final +/- | S_1 calls changed | prev drift final +/- | prev calls changed | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r1/S1_dev | all | 0.625 | 0.555 | 7.000 | 0.320 | 0.305 | 0.200 | 0.085 | 0.025 | +0/-0 | +0/-0 | 0 | - | - | pass |
| r1/grpo_dev | all | 0.630 | 0.555 | 7.500 | 0.325 | 0.320 | 0.213 | 0.085 | 0.020 | +3/-3 | +4/-3 | 11 | +4/-3 | 11 | pass |
| r2/static/sft_dev | static | 0.620 | 0.560 | 6.000 | 0.255 | 0.250 | 0.183 | 0.070 | 0.015 | +3/-2 | +4/-5 | 21 | +4/-5 | 21 | pass |
| r2/static/grpo_dev | static | 0.610 | 0.575 | 3.500 | 0.270 | 0.255 | 0.109 | 0.060 | 0.025 | +6/-2 | +3/-6 | 24 | +3/-5 | 17 | pass |
| r3/static/sft_dev | static | 0.605 | 0.555 | 5.000 | 0.180 | 0.170 | 0.099 | 0.060 | 0.010 | +4/-4 | +5/-9 | 37 | +5/-6 | 29 | pass |
| r3/static/grpo_dev | static | 0.620 | 0.565 | 5.500 | 0.275 | 0.265 | 0.121 | 0.080 | 0.025 | +8/-6 | +9/-10 | 36 | +9/-6 | 23 | pass |

## Arms: resolved checkpoint per round (G_k, or S_k when GRPO was rejected)

| static: round | G stage | GRPO rejected | acc | calls | call gap |
|---|---|---|---|---|---|
| 1 | r1/grpo_dev | True | 0.625 | 0.320 | 0.200 |
| 2 | r2/static/grpo_dev | False | 0.610 | 0.270 | 0.109 |
| 3 | r3/static/grpo_dev | False | 0.620 | 0.275 | 0.121 |

## Label mix

| stage | rule | rows | commit | call | commit after call | rescue dec | commit dec |
|---|---|---|---|---|---|---|---|
| static/select | static | 331 | - | - | - | - | - |

## FA-GRPO

| stage | lr | steps | selected step | guard ok | informative frac |
|---|---|---|---|---|---|
| r1/grpo | 0.000 | 24 | 16 | False | 0.094 |
| r2/static/grpo | 0.000 | 64 | 64 | True | 0.246 |
| r3/static/grpo | 0.000 | 64 | 64 | True | 0.202 |

## Gates

- r1/S1_dev: parity pass
- r1/grpo_dev: grpo_rejected ['FA-GRPO stage was uninformative (< 15% revision states with J in (0.02, 0.98))']
- r2/static/grpo_dev: grpo_accepted 
- r3/static/grpo_dev: grpo_accepted 

## Locked test and forced baselines (Table 3 analogue)

| stage | label | pool | forced | n | candidate | acc | gain pp | calls | call gap | gate |
|---|---|---|---|---|---|---|---|---|---|---|
| final/S_1/dev_forced_extractor | S_1 | dev | extractor | 200 | - | 0.525 | - | 1.000 | - | valid_answer_rate=0.995 |
| final/S_1/dev_forced_extractor+reasoner+verifier | S_1 | dev | extractor,reasoner,verifier | 200 | - | 0.675 | - | 3.000 | - | pass |
| final/S_1/dev_forced_reasoner | S_1 | dev | reasoner | 200 | - | 0.575 | - | 1.000 | - | pass |
| final/S_1/dev_forced_verifier | S_1 | dev | verifier | 200 | - | 0.670 | - | 1.000 | - | pass |
| final/S_1/test | S_1 | test | - | 500 | 0.510 | 0.636 | 12.600 | 0.352 | 0.309 | pass |
| final/S_1/test_paper | S_1 | test_paper | - | 500 | 0.492 | 0.596 | 10.400 | 0.348 | 0.265 | pass |
| final/static/dev_forced_extractor | static | dev | extractor | 200 | - | 0.550 | - | 1.000 | - | valid_answer_rate=0.97 |
| final/static/dev_forced_extractor+reasoner+verifier | static | dev | extractor,reasoner,verifier | 200 | - | 0.680 | - | 3.000 | - | pass |
| final/static/dev_forced_reasoner | static | dev | reasoner | 200 | - | 0.585 | - | 1.000 | - | pass |
| final/static/dev_forced_verifier | static | dev | verifier | 200 | - | 0.680 | - | 1.000 | - | pass |
| final/static/test | static | test | - | 500 | 0.526 | 0.614 | 8.800 | 0.264 | 0.211 | pass |
| final/static/test_paper | static | test_paper | - | 500 | 0.502 | 0.580 | 7.800 | 0.280 | 0.214 | pass |
